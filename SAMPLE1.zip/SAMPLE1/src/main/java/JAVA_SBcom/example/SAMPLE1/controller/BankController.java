package JAVA_SBcom.example.SAMPLE1.controller;
import JAVA_SBcom.example.SAMPLE1.model.Account;
import JAVA_SBcom.example.SAMPLE1.service.BankService;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
public class BankController {
    private final BankService bankService;
    public BankController(BankService bankService) {
        this.bankService = bankService;
    }
    @GetMapping("/accounts")
    public List<Account> getAllAccounts() {
        return bankService.getAllAccounts();
    }
    @GetMapping("/balance/{id}")
    public Object getBalance(@PathVariable int id) {
        Account account = bankService.getAccount(id);
        if (account == null) {
            return "Account not found";
        }
        return account;
    }
    @PostMapping("/deposit/{id}")
    public String deposit(
            @PathVariable int id,
            @RequestBody double amount) {
        return bankService.deposit(id, amount);
    }
    @PostMapping("/withdraw/{id}")
    public String withdraw(
            @PathVariable int id,
            @RequestBody double amount) {
        return bankService.withdraw(id, amount);
    }
}