package JAVA_SBcom.example.SAMPLE1.service;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Service;

import JAVA_SBcom.example.SAMPLE1.model.Account;
@Service
public class BankService {
    private final DataSource dataSource;
    public BankService(DataSource dataSource) {
        this.dataSource = dataSource;
    }
    public List<Account> getAllAccounts() {
        List<Account> accounts = new ArrayList<>();
        String query = "SELECT * FROM accounts";
        try (
                Connection connection = dataSource.getConnection();
                PreparedStatement statement = connection.prepareStatement(query);
                ResultSet resultSet = statement.executeQuery()
        ) {
            while (resultSet.next()) {
                Account account = new Account();
                account.setId(resultSet.getInt("id"));
                account.setName(resultSet.getString("name"));
                account.setBalance(resultSet.getDouble("balance"));
                accounts.add(account);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return accounts;
    }
    public Account getAccount(int id) {
        String query = "SELECT * FROM accounts WHERE id = ?";
        try (
                Connection connection = dataSource.getConnection();
                PreparedStatement statement = connection.prepareStatement(query)
        ) {
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                Account account = new Account();
                account.setId(resultSet.getInt("id"));
                account.setName(resultSet.getString("name"));
                account.setBalance(resultSet.getDouble("balance"));
                return account;
                
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    public String deposit(int id, double amount) {
        if (amount <= 0) {
            return "Amount must be greater than 0";
        }
        String query = "UPDATE accounts SET balance = balance + ? WHERE id = ?";
        try (
                Connection connection = dataSource.getConnection();
                PreparedStatement statement = connection.prepareStatement(query)
        ) {
            statement.setDouble(1, amount);
            statement.setInt(2, id);
            int rows = statement.executeUpdate();
            if (rows == 0) {
                return "Account not found";
            }
            return "Deposit successful. Amount deposited: " + amount;
        } catch (SQLException e) {
            e.printStackTrace();
            return "Database error";
        }
    }
    public String withdraw(int id, double amount) {
        if (amount <= 0) {
            return "Amount must be greater than 0";
        }
        Account account = getAccount(id);
        if (account == null) {
            return "Account not found";
        }
        if (account.getBalance() < amount) {
            return "Insufficient balance";
        }
        String query = "UPDATE accounts SET balance = balance - ? WHERE id = ?";
        try (
                Connection connection = dataSource.getConnection();
                PreparedStatement statement = connection.prepareStatement(query)
        ) {
            statement.setDouble(1, amount);
            statement.setInt(2, id);
            statement.executeUpdate();
            return "Withdrawal successful. Amount withdrawn: " + amount;
        } catch (SQLException e) {
            e.printStackTrace();
            return "Database error";
        }
    }
}