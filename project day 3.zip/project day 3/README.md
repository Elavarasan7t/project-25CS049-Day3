# Public EV Fleet Battery Swapping & Circular Recycling Network
**Project Leap – Java & DBMS – Day 3 (UI Interface)**  
*Project ID: 47*

---

## 1. Executive Overview
A clean transit logistics platform managing EV battery swapping stations, tracking battery health degradation, billing electric taxi fleets for instant battery swaps, and controlling circular battery recycling budgets.

### Primary Actors & Capabilities:
- **Admin (Battery Network Director)**: Sets swap pricing, monitors real-time battery fleet health degradation curves, configures circular recycling thresholds, and audits financial statements.
- **Invoicing User (Network Accountant)**: Bills electric taxi fleets for swap subscriptions, generates POs for certified battery recycling specialists, processes vendor bills, and handles bank reconciliations.
- **Fleet Driver**: Initiates automated 3-minute swaps at smart bay kiosks, receives instantaneous digital swap receipts with energy & fee telemetry, and views health diagnostics.
- **Autonomous System Engine**: Continuously ingests battery state-of-health ($\text{SoH}$) telemetry. When $\text{SoH} < 70\%$, the pack is automatically retired from transit duty, flagged for circular hydrometallurgical recycling, and an automated procurement order is dispatched.

---

## 2. Architecture & Tech Stack
- **Backend**: Spring Boot 3.3.4 (Java 21 / 26 compatible)
  - Spring Web (REST API Controllers)
  - Spring Data JPA / Hibernate (Relational ORM)
  - Validation API
- **Database (DBMS)**: Relational DBMS (H2 In-Memory with full ANSI SQL support & web console at `/h2-console`, compatible with MySQL)
- **Frontend UI**: Responsive Single-Page Application (SPA) with Cyber-Transit Dark Mode aesthetics
  - Vanilla CSS3 with Glassmorphism, Neon Glow accents, and responsive grid layouts
  - Vanilla JavaScript ES6+ communicating asynchronously via REST endpoints
  - FontAwesome 6.5 icons & Google Fonts (Inter & JetBrains Mono)

---

## 3. Master Data Modules
1. **Contact Master**:
   - Electric Taxi Fleets (*Customer*): MetroVolt Green Cabs, EcoRide City Fleet, Apex Express EV Taxis
   - Battery Cell Manufacturers (*Vendor*): CATL NextGen Cells Ltd, Panasonic EV Chem Corp
   - Recycling Specialists (*Vendor*): EcoLithium Circular Recycling Specialists Ltd
2. **Product Master**:
   - `PROD-SWAP`: Rapid Battery Swap Session (Service, $38.50)
   - `PROD-LEASE`: Battery Module Fleet Lease (Service, $320.00/mo)
   - `PROD-RECYC`: Cell Circular Recycling Service (Service, $650.00/module)
3. **Chart of Accounts (CoA)**:
   - **Assets**: `1010` Swappable Battery Pack Inventory, `1015` Charging Bay Infrastructure, `1020` Cash/Bank
   - **Liabilities**: `2010` Battery Manufacturer Creditors, `2020` Grid Power Payables
   - **Equity**: `3010` Clean Mobility Equity Capital
   - **Income**: `4010` Battery Swap Revenues, `4020` Subscription Fees
   - **Expenses**: `5010` Grid Electricity Expenditures, `5020` Battery Recycling Costs
4. **Journals**:
   - `SJ`: Sales Journal (Swap revenues and customer invoices)
   - `PJ`: Purchase Journal (Recycling PO bills and creditor payables)
   - `CJ`: Cash Journal (Counter transactions)
   - `BJ`: Bank Journal (Direct debits and settlements)
5. **Analytic Accounts & Budgets**:
   - Station Zones: Central Depot Zone A, Tech Corridor Zone B, Airport Express Zone C, Metro West Zone D
   - Operational budgets tracking actual electricity expenditures, recycling fees, and swap revenues against planned allocations.

---

## 4. Key Use-Case Implementation & API Verification

### Step 1: Create Master Data
Add a battery pack asset via `POST /api/batteries/packs`:
```bash
curl -X POST http://localhost:8080/api/batteries/packs \
  -H "Content-Type: application/json" \
  -d '{
    "serialNumber": "BP-LFP-9005",
    "chemistry": "LFP (Lithium Iron Phosphate)",
    "nominalCapacityKwh": 75.0,
    "stateOfHealth": 98.5,
    "stationZone": "ZONE-A",
    "assetValuation": 8900.0,
    "status": "CHARGING_AT_BAY"
  }'
```

### Step 2: Process Battery Swap (With Autonomous Circular Recycling)
Ingest a swap event via `POST /api/batteries/swaps`.
- If the depleted pack's $\text{SoH} < 70\%$, the system:
  1. Sets pack status to `RETIRED_FOR_RECYCLING`
  2. Sets `autoRoutedToRecycling = true`
  3. Automatically drafts a Purchase Order for EcoLithium Circular Specialist
  4. Balances double-entry ledger in Sales Journal (Debit Bank $38.50, Credit Swap Revenue $38.50, Debit Grid Power Expense, Credit Grid Power Payables).
```bash
curl -X POST http://localhost:8080/api/batteries/swaps \
  -H "Content-Type: application/json" \
  -d '{
    "stationId": 1,
    "customerId": 1,
    "taxiPlateNumber": "MV-TX-999",
    "driverName": "Samantha Ray",
    "depletedBatteryId": 2,
    "customDepletedSoH": 66.4
  }'
```

### Step 3: Record Financial Transactions
- **Convert PO to Vendor Bill**: `POST /api/transactions/purchase-orders/{id}/convert-to-bill`
- **Convert Sales Order to Customer Invoice**: `POST /api/transactions/sales-orders/{id}/convert-to-invoice`
- **Bank Settlement**: `POST /api/transactions/payments`

### Step 4: Generate Reports
- **Balance Sheet**: `GET /api/reports/balance-sheet`
- **Profit & Loss**: `GET /api/reports/profit-and-loss`
- **Zone Budget Report**: `GET /api/reports/budget-report`

---

## 5. Running the Application Locally
```bash
# 1. Build the project
mvn clean compile

# 2. Run automated tests (100% pass)
mvn test

# 3. Start Spring Boot Dev Server
mvn spring-boot:run
```
Once started:
- **Web Application UI**: [http://localhost:8080/](http://localhost:8080/)
- **H2 DBMS SQL Console**: [http://localhost:8080/h2-console](http://localhost:8080/h2-console)
  - JDBC URL: `jdbc:h2:mem:evnetworkdb`
  - User: `sa`
  - Password: *(leave blank)*

---

## 6. Submission Guide for Day 3 Assignment
1. **Initialize Git Repository**:
   ```bash
   git init
   git add .
   git commit -m "Complete Project Leap Day 3: EV Battery Swapping & Circular Recycling Network with UI"
   ```
2. **Push to Your Assigned GitHub Repository**:
   ```bash
   git branch -M main
   git remote add origin https://github.com/Project-Leap-2026/YOUR_ASSIGNED_REPO.git
   git push -u origin main
   ```
3. Copy your GitHub repository link and submit it on the Project Leap Day 3 assignment page.
