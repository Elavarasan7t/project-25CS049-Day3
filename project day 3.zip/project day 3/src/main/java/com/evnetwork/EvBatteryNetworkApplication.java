package com.evnetwork;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EvBatteryNetworkApplication {

    public static void main(String[] args) {
        SpringApplication.run(EvBatteryNetworkApplication.class, args);
    }
}
