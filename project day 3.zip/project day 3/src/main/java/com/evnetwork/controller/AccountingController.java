package com.evnetwork.controller;

import com.evnetwork.entity.*;
import com.evnetwork.service.AccountingService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
public class AccountingController {

    private final AccountingService accountingService;

    public AccountingController(AccountingService accountingService) {
        this.accountingService = accountingService;
    }

    // --- 1. Contact Master ---
    @GetMapping("/api/contacts")
    public ResponseEntity<List<Contact>> getContacts() {
        return ResponseEntity.ok(accountingService.getAllContacts());
    }

    @PostMapping("/api/contacts")
    public ResponseEntity<Contact> createContact(@RequestBody Contact contact) {
        return ResponseEntity.ok(accountingService.saveContact(contact));
    }

    // --- 2. Product Master ---
    @GetMapping("/api/products")
    public ResponseEntity<List<Product>> getProducts() {
        return ResponseEntity.ok(accountingService.getAllProducts());
    }

    @PostMapping("/api/products")
    public ResponseEntity<Product> createProduct(@RequestBody Product product) {
        return ResponseEntity.ok(accountingService.saveProduct(product));
    }

    // --- 3. Chart of Accounts (CoA) ---
    @GetMapping("/api/accounting/coa")
    public ResponseEntity<List<Account>> getChartOfAccounts() {
        return ResponseEntity.ok(accountingService.getAllAccounts());
    }

    @PostMapping("/api/accounting/coa")
    public ResponseEntity<Account> createAccount(@RequestBody Account account) {
        return ResponseEntity.ok(accountingService.saveAccount(account));
    }

    // --- 4. Journals ---
    @GetMapping("/api/accounting/journals")
    public ResponseEntity<List<Journal>> getJournals() {
        return ResponseEntity.ok(accountingService.getAllJournals());
    }

    @GetMapping("/api/accounting/journal-entries")
    public ResponseEntity<List<JournalEntry>> getJournalEntries() {
        return ResponseEntity.ok(accountingService.getAllJournalEntries());
    }

    @PostMapping("/api/accounting/journal-entries")
    public ResponseEntity<JournalEntry> createJournalEntry(@RequestBody CreateJournalEntryRequest request) {
        JournalEntry entry = accountingService.recordJournalEntry(
                request.getJournalCode(),
                request.getReference(),
                request.getDescription(),
                request.getLines()
        );
        return ResponseEntity.ok(entry);
    }

    // --- 5. Purchase Orders ---
    @GetMapping("/api/transactions/purchase-orders")
    public ResponseEntity<List<PurchaseOrder>> getPurchaseOrders() {
        return ResponseEntity.ok(accountingService.getAllPurchaseOrders());
    }

    @PostMapping("/api/transactions/purchase-orders")
    public ResponseEntity<PurchaseOrder> createPurchaseOrder(@RequestBody PurchaseOrder po) {
        return ResponseEntity.ok(accountingService.createPurchaseOrder(po));
    }

    @PostMapping("/api/transactions/purchase-orders/{id}/convert-to-bill")
    public ResponseEntity<VendorBill> convertPOToVendorBill(@PathVariable Long id) {
        return ResponseEntity.ok(accountingService.convertPOToVendorBill(id));
    }

    // --- 6. Vendor Bills ---
    @GetMapping("/api/transactions/vendor-bills")
    public ResponseEntity<List<VendorBill>> getVendorBills() {
        return ResponseEntity.ok(accountingService.getAllVendorBills());
    }

    // --- 7. Sales Orders ---
    @GetMapping("/api/transactions/sales-orders")
    public ResponseEntity<List<SalesOrder>> getSalesOrders() {
        return ResponseEntity.ok(accountingService.getAllSalesOrders());
    }

    @PostMapping("/api/transactions/sales-orders")
    public ResponseEntity<SalesOrder> createSalesOrder(@RequestBody SalesOrder so) {
        return ResponseEntity.ok(accountingService.createSalesOrder(so));
    }

    @PostMapping("/api/transactions/sales-orders/{id}/convert-to-invoice")
    public ResponseEntity<CustomerInvoice> convertSOToCustomerInvoice(@PathVariable Long id) {
        return ResponseEntity.ok(accountingService.convertSOToCustomerInvoice(id));
    }

    // --- 8. Customer Invoices ---
    @GetMapping("/api/transactions/customer-invoices")
    public ResponseEntity<List<CustomerInvoice>> getCustomerInvoices() {
        return ResponseEntity.ok(accountingService.getAllCustomerInvoices());
    }

    // --- 9. Payments (Bank Settlements) ---
    @GetMapping("/api/transactions/payments")
    public ResponseEntity<List<Payment>> getPayments() {
        return ResponseEntity.ok(accountingService.getAllPayments());
    }

    @PostMapping("/api/transactions/payments")
    public ResponseEntity<Payment> processPayment(@RequestBody Payment payment) {
        return ResponseEntity.ok(accountingService.processPayment(payment));
    }

    public static class CreateJournalEntryRequest {
        private String journalCode;
        private String reference;
        private String description;
        private List<JournalLine> lines;

        public String getJournalCode() { return journalCode; }
        public void setJournalCode(String journalCode) { this.journalCode = journalCode; }

        public String getReference() { return reference; }
        public void setReference(String reference) { this.reference = reference; }

        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }

        public List<JournalLine> getLines() { return lines; }
        public void setLines(List<JournalLine> lines) { this.lines = lines; }
    }
}
