package com.evnetwork.controller;

import com.evnetwork.entity.BatteryPack;
import com.evnetwork.entity.BatterySwapEvent;
import com.evnetwork.entity.SwapStation;
import com.evnetwork.service.BatteryService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/batteries")
@CrossOrigin(origins = "*")
public class BatteryController {

    private final BatteryService batteryService;

    public BatteryController(BatteryService batteryService) {
        this.batteryService = batteryService;
    }

    // Step 1: Create Master Data - Add battery pack asset (POST /api/batteries/packs)
    @PostMapping("/packs")
    public ResponseEntity<BatteryPack> registerBatteryPack(@RequestBody BatteryPack pack) {
        BatteryPack created = batteryService.registerBatteryPack(pack);
        return ResponseEntity.ok(created);
    }

    @GetMapping("/packs")
    public ResponseEntity<List<BatteryPack>> getAllPacks(
            @RequestParam(required = false) String status) {
        if (status != null && !status.isBlank()) {
            try {
                BatteryPack.BatteryStatus s = BatteryPack.BatteryStatus.valueOf(status.toUpperCase());
                return ResponseEntity.ok(batteryService.getPacksByStatus(s));
            } catch (IllegalArgumentException ignored) {}
        }
        return ResponseEntity.ok(batteryService.getAllBatteryPacks());
    }

    @GetMapping("/packs/degraded")
    public ResponseEntity<List<BatteryPack>> getDegradedPacks() {
        return ResponseEntity.ok(batteryService.getDegradedPacks());
    }

    // Step 2: Process Battery Swap - Ingest swap event (POST /api/batteries/swaps)
    @PostMapping("/swaps")
    public ResponseEntity<BatterySwapEvent> processBatterySwap(@RequestBody SwapRequest request) {
        BatterySwapEvent event = batteryService.processBatterySwap(
                request.getStationId(),
                request.getCustomerId(),
                request.getTaxiPlateNumber(),
                request.getDriverName(),
                request.getDepletedBatteryId(),
                request.getInstalledBatteryId(),
                request.getCustomDepletedSoH()
        );
        return ResponseEntity.ok(event);
    }

    @GetMapping("/swaps")
    public ResponseEntity<List<BatterySwapEvent>> getAllSwaps() {
        return ResponseEntity.ok(batteryService.getAllSwapEvents());
    }

    @GetMapping("/telemetry/stats")
    public ResponseEntity<Map<String, Object>> getTelemetryStats() {
        return ResponseEntity.ok(batteryService.getTelemetryStats());
    }

    @GetMapping("/stations")
    public ResponseEntity<List<SwapStation>> getAllStations() {
        return ResponseEntity.ok(batteryService.getAllStations());
    }

    @PostMapping("/stations")
    public ResponseEntity<SwapStation> createStation(@RequestBody SwapStation station) {
        return ResponseEntity.ok(batteryService.saveStation(station));
    }

    // DTO for swap request
    public static class SwapRequest {
        private Long stationId;
        private Long customerId;
        private String taxiPlateNumber;
        private String driverName;
        private Long depletedBatteryId;
        private Long installedBatteryId;
        private Double customDepletedSoH; // Optional: used for interactive driver simulation

        public Long getStationId() { return stationId; }
        public void setStationId(Long stationId) { this.stationId = stationId; }

        public Long getCustomerId() { return customerId; }
        public void setCustomerId(Long customerId) { this.customerId = customerId; }

        public String getTaxiPlateNumber() { return taxiPlateNumber; }
        public void setTaxiPlateNumber(String taxiPlateNumber) { this.taxiPlateNumber = taxiPlateNumber; }

        public String getDriverName() { return driverName; }
        public void setDriverName(String driverName) { this.driverName = driverName; }

        public Long getDepletedBatteryId() { return depletedBatteryId; }
        public void setDepletedBatteryId(Long depletedBatteryId) { this.depletedBatteryId = depletedBatteryId; }

        public Long getInstalledBatteryId() { return installedBatteryId; }
        public void setInstalledBatteryId(Long installedBatteryId) { this.installedBatteryId = installedBatteryId; }

        public Double getCustomDepletedSoH() { return customDepletedSoH; }
        public void setCustomDepletedSoH(Double customDepletedSoH) { this.customDepletedSoH = customDepletedSoH; }
    }
}
