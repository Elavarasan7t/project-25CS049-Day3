package com.evnetwork.controller;

import com.evnetwork.entity.AnalyticAccount;
import com.evnetwork.entity.Budget;
import com.evnetwork.service.BudgetService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/budgets")
@CrossOrigin(origins = "*")
public class BudgetController {

    private final BudgetService budgetService;

    public BudgetController(BudgetService budgetService) {
        this.budgetService = budgetService;
    }

    @GetMapping("/analytic-accounts")
    public ResponseEntity<List<AnalyticAccount>> getAnalyticAccounts() {
        return ResponseEntity.ok(budgetService.getAllAnalyticAccounts());
    }

    @PostMapping("/analytic-accounts")
    public ResponseEntity<AnalyticAccount> createAnalyticAccount(@RequestBody AnalyticAccount account) {
        return ResponseEntity.ok(budgetService.saveAnalyticAccount(account));
    }

    @GetMapping
    public ResponseEntity<List<Budget>> getBudgets() {
        return ResponseEntity.ok(budgetService.getAllBudgets());
    }

    @PostMapping
    public ResponseEntity<Budget> createBudget(@RequestBody Budget budget) {
        return ResponseEntity.ok(budgetService.saveBudget(budget));
    }

    @GetMapping("/performance")
    public ResponseEntity<List<Map<String, Object>>> getBudgetPerformance() {
        return ResponseEntity.ok(budgetService.getBudgetPerformanceReport());
    }
}
