package com.evnetwork.controller;

import com.evnetwork.service.ReportService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins = "*")
public class ReportController {

    private final ReportService reportService;

    public ReportController(ReportService reportService) {
        this.reportService = reportService;
    }

    // Step 4: Generate Reports - Run Battery Network P&L and Station Budget Reports
    @GetMapping("/balance-sheet")
    public ResponseEntity<Map<String, Object>> getBalanceSheet() {
        return ResponseEntity.ok(reportService.getBalanceSheet());
    }

    @GetMapping("/profit-and-loss")
    public ResponseEntity<Map<String, Object>> getProfitAndLoss() {
        return ResponseEntity.ok(reportService.getProfitAndLoss());
    }

    @GetMapping("/budget-report")
    public ResponseEntity<List<Map<String, Object>>> getBudgetReport() {
        return ResponseEntity.ok(reportService.getBudgetReport());
    }
}
