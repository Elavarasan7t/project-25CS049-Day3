package com.evnetwork.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "accounts")
public class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String code; // e.g., "1010", "1020", "2010", etc.

    @Column(nullable = false)
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private AccountType type; // ASSET, LIABILITY, EQUITY, INCOME, EXPENSE

    private String subCategory; // Current Asset, Fixed Asset, Current Liability, Operating Income, Operating Expense
    private Double balance; // Current debit - credit for asset/expense, credit - debit for liab/income

    public enum AccountType {
        ASSET,
        LIABILITY,
        EQUITY,
        INCOME,
        EXPENSE
    }

    public Account() {}

    public Account(String code, String name, AccountType type, String subCategory, Double balance) {
        this.code = code;
        this.name = name;
        this.type = type;
        this.subCategory = subCategory;
        this.balance = balance;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public AccountType getType() { return type; }
    public void setType(AccountType type) { this.type = type; }

    public String getSubCategory() { return subCategory; }
    public void setSubCategory(String subCategory) { this.subCategory = subCategory; }

    public Double getBalance() { return balance; }
    public void setBalance(Double balance) { this.balance = balance; }
}
