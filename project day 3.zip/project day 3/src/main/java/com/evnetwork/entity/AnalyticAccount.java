package com.evnetwork.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "analytic_accounts")
public class AnalyticAccount {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String code; // ZONE-A, ZONE-B, ZONE-C, ZONE-D

    @Column(nullable = false)
    private String name; // Central Depot Zone A, Downtown Hub Zone B, etc.

    private String description;
    private Boolean active;

    public AnalyticAccount() {}

    public AnalyticAccount(String code, String name, String description, Boolean active) {
        this.code = code;
        this.name = name;
        this.description = description;
        this.active = active;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public Boolean getActive() { return active; }
    public void setActive(Boolean active) { this.active = active; }
}
