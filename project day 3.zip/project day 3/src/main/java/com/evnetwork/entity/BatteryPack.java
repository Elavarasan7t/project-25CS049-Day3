package com.evnetwork.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "battery_packs")
public class BatteryPack {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String serialNumber;

    private String chemistry; // LFP, NMC, SolidState
    private Double nominalCapacityKwh;
    private Double currentCapacityKwh;
    private Double stateOfHealth; // Percentage: 0.0 - 100.0%
    private Integer cycleCount;

    @Enumerated(EnumType.STRING)
    private BatteryStatus status; // IN_SERVICE, CHARGING_AT_BAY, IN_TRANSIT, RETIRED_FOR_RECYCLING

    private String stationZone; // e.g., Central Depot Zone A
    private LocalDateTime manufacturingDate;
    private LocalDateTime lastSwapTimestamp;
    private Double assetValuation; // Value tracked on Balance Sheet

    public enum BatteryStatus {
        IN_SERVICE,
        CHARGING_AT_BAY,
        IN_TRANSIT,
        RETIRED_FOR_RECYCLING
    }

    public BatteryPack() {}

    public BatteryPack(String serialNumber, String chemistry, Double nominalCapacityKwh, Double stateOfHealth, Integer cycleCount, BatteryStatus status, String stationZone, Double assetValuation) {
        this.serialNumber = serialNumber;
        this.chemistry = chemistry;
        this.nominalCapacityKwh = nominalCapacityKwh;
        this.stateOfHealth = stateOfHealth;
        this.currentCapacityKwh = (nominalCapacityKwh * stateOfHealth) / 100.0;
        this.cycleCount = cycleCount;
        this.status = status;
        this.stationZone = stationZone;
        this.manufacturingDate = LocalDateTime.now().minusMonths(6);
        this.lastSwapTimestamp = LocalDateTime.now();
        this.assetValuation = assetValuation;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getSerialNumber() { return serialNumber; }
    public void setSerialNumber(String serialNumber) { this.serialNumber = serialNumber; }

    public String getChemistry() { return chemistry; }
    public void setChemistry(String chemistry) { this.chemistry = chemistry; }

    public Double getNominalCapacityKwh() { return nominalCapacityKwh; }
    public void setNominalCapacityKwh(Double nominalCapacityKwh) { this.nominalCapacityKwh = nominalCapacityKwh; }

    public Double getCurrentCapacityKwh() { return currentCapacityKwh; }
    public void setCurrentCapacityKwh(Double currentCapacityKwh) { this.currentCapacityKwh = currentCapacityKwh; }

    public Double getStateOfHealth() { return stateOfHealth; }
    public void setStateOfHealth(Double stateOfHealth) {
        this.stateOfHealth = stateOfHealth;
        if (this.nominalCapacityKwh != null) {
            this.currentCapacityKwh = (this.nominalCapacityKwh * stateOfHealth) / 100.0;
        }
    }

    public Integer getCycleCount() { return cycleCount; }
    public void setCycleCount(Integer cycleCount) { this.cycleCount = cycleCount; }

    public BatteryStatus getStatus() { return status; }
    public void setStatus(BatteryStatus status) { this.status = status; }

    public String getStationZone() { return stationZone; }
    public void setStationZone(String stationZone) { this.stationZone = stationZone; }

    public LocalDateTime getManufacturingDate() { return manufacturingDate; }
    public void setManufacturingDate(LocalDateTime manufacturingDate) { this.manufacturingDate = manufacturingDate; }

    public LocalDateTime getLastSwapTimestamp() { return lastSwapTimestamp; }
    public void setLastSwapTimestamp(LocalDateTime lastSwapTimestamp) { this.lastSwapTimestamp = lastSwapTimestamp; }

    public Double getAssetValuation() { return assetValuation; }
    public void setAssetValuation(Double assetValuation) { this.assetValuation = assetValuation; }
}
