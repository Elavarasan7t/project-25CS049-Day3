package com.evnetwork.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "battery_swap_events")
public class BatterySwapEvent {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String receiptNumber;

    private LocalDateTime swapTimestamp;
    private Long stationId;
    private String stationName;
    private String zoneCode;

    private Long customerId;
    private String taxiFleetName;
    private String taxiPlateNumber;
    private String driverName;

    // Depleted incoming battery
    private Long depletedBatteryId;
    private String depletedBatterySerial;
    private Double depletedBatterySoH;

    // Installed fresh battery
    private Long installedBatteryId;
    private String installedBatterySerial;
    private Double installedBatterySoH;

    private Double energyDeliveredKwh;
    private Double serviceFee;
    private Double gridElectricityCost;

    private Boolean autoRoutedToRecycling; // True if depletedBatterySoH < 70.0
    private String recyclingReason;
    private String status; // COMPLETED, CANCELLED

    public BatterySwapEvent() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getReceiptNumber() { return receiptNumber; }
    public void setReceiptNumber(String receiptNumber) { this.receiptNumber = receiptNumber; }

    public LocalDateTime getSwapTimestamp() { return swapTimestamp; }
    public void setSwapTimestamp(LocalDateTime swapTimestamp) { this.swapTimestamp = swapTimestamp; }

    public Long getStationId() { return stationId; }
    public void setStationId(Long stationId) { this.stationId = stationId; }

    public String getStationName() { return stationName; }
    public void setStationName(String stationName) { this.stationName = stationName; }

    public String getZoneCode() { return zoneCode; }
    public void setZoneCode(String zoneCode) { this.zoneCode = zoneCode; }

    public Long getCustomerId() { return customerId; }
    public void setCustomerId(Long customerId) { this.customerId = customerId; }

    public String getTaxiFleetName() { return taxiFleetName; }
    public void setTaxiFleetName(String taxiFleetName) { this.taxiFleetName = taxiFleetName; }

    public String getTaxiPlateNumber() { return taxiPlateNumber; }
    public void setTaxiPlateNumber(String taxiPlateNumber) { this.taxiPlateNumber = taxiPlateNumber; }

    public String getDriverName() { return driverName; }
    public void setDriverName(String driverName) { this.driverName = driverName; }

    public Long getDepletedBatteryId() { return depletedBatteryId; }
    public void setDepletedBatteryId(Long depletedBatteryId) { this.depletedBatteryId = depletedBatteryId; }

    public String getDepletedBatterySerial() { return depletedBatterySerial; }
    public void setDepletedBatterySerial(String depletedBatterySerial) { this.depletedBatterySerial = depletedBatterySerial; }

    public Double getDepletedBatterySoH() { return depletedBatterySoH; }
    public void setDepletedBatterySoH(Double depletedBatterySoH) { this.depletedBatterySoH = depletedBatterySoH; }

    public Long getInstalledBatteryId() { return installedBatteryId; }
    public void setInstalledBatteryId(Long installedBatteryId) { this.installedBatteryId = installedBatteryId; }

    public String getInstalledBatterySerial() { return installedBatterySerial; }
    public void setInstalledBatterySerial(String installedBatterySerial) { this.installedBatterySerial = installedBatterySerial; }

    public Double getInstalledBatterySoH() { return installedBatterySoH; }
    public void setInstalledBatterySoH(Double installedBatterySoH) { this.installedBatterySoH = installedBatterySoH; }

    public Double getEnergyDeliveredKwh() { return energyDeliveredKwh; }
    public void setEnergyDeliveredKwh(Double energyDeliveredKwh) { this.energyDeliveredKwh = energyDeliveredKwh; }

    public Double getServiceFee() { return serviceFee; }
    public void setServiceFee(Double serviceFee) { this.serviceFee = serviceFee; }

    public Double getGridElectricityCost() { return gridElectricityCost; }
    public void setGridElectricityCost(Double gridElectricityCost) { this.gridElectricityCost = gridElectricityCost; }

    public Boolean getAutoRoutedToRecycling() { return autoRoutedToRecycling; }
    public void setAutoRoutedToRecycling(Boolean autoRoutedToRecycling) { this.autoRoutedToRecycling = autoRoutedToRecycling; }

    public String getRecyclingReason() { return recyclingReason; }
    public void setRecyclingReason(String recyclingReason) { this.recyclingReason = recyclingReason; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
