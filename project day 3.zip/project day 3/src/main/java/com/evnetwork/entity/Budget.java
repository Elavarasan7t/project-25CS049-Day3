package com.evnetwork.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "budgets")
public class Budget {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name; // e.g. "FY2026 Zone A Operational Budget"

    private String fiscalYear; // e.g. "2026"
    private String zoneCode; // ZONE-A, ZONE-B, etc.
    private String analyticAccountName;

    // Planned figures
    private Double plannedSwapRevenue;
    private Double plannedGridExpense;
    private Double plannedRecyclingExpense;

    public Budget() {}

    public Budget(String name, String fiscalYear, String zoneCode, String analyticAccountName, Double plannedSwapRevenue, Double plannedGridExpense, Double plannedRecyclingExpense) {
        this.name = name;
        this.fiscalYear = fiscalYear;
        this.zoneCode = zoneCode;
        this.analyticAccountName = analyticAccountName;
        this.plannedSwapRevenue = plannedSwapRevenue;
        this.plannedGridExpense = plannedGridExpense;
        this.plannedRecyclingExpense = plannedRecyclingExpense;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getFiscalYear() { return fiscalYear; }
    public void setFiscalYear(String fiscalYear) { this.fiscalYear = fiscalYear; }

    public String getZoneCode() { return zoneCode; }
    public void setZoneCode(String zoneCode) { this.zoneCode = zoneCode; }

    public String getAnalyticAccountName() { return analyticAccountName; }
    public void setAnalyticAccountName(String analyticAccountName) { this.analyticAccountName = analyticAccountName; }

    public Double getPlannedSwapRevenue() { return plannedSwapRevenue; }
    public void setPlannedSwapRevenue(Double plannedSwapRevenue) { this.plannedSwapRevenue = plannedSwapRevenue; }

    public Double getPlannedGridExpense() { return plannedGridExpense; }
    public void setPlannedGridExpense(Double plannedGridExpense) { this.plannedGridExpense = plannedGridExpense; }

    public Double getPlannedRecyclingExpense() { return plannedRecyclingExpense; }
    public void setPlannedRecyclingExpense(Double plannedRecyclingExpense) { this.plannedRecyclingExpense = plannedRecyclingExpense; }
}
