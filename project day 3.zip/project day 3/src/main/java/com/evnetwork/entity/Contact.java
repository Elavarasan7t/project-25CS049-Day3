package com.evnetwork.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "contacts")
public class Contact {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ContactType type; // CUSTOMER, VENDOR_MANUFACTURER, VENDOR_RECYCLER

    private String email;
    private String phone;
    private String address;
    private String taxNumber;
    private Double outstandingBalance; // AR for Customer, AP for Vendor

    public enum ContactType {
        CUSTOMER,
        VENDOR_MANUFACTURER,
        VENDOR_RECYCLER
    }

    public Contact() {}

    public Contact(String name, ContactType type, String email, String phone, String address, String taxNumber, Double outstandingBalance) {
        this.name = name;
        this.type = type;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.taxNumber = taxNumber;
        this.outstandingBalance = outstandingBalance;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public ContactType getType() { return type; }
    public void setType(ContactType type) { this.type = type; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getTaxNumber() { return taxNumber; }
    public void setTaxNumber(String taxNumber) { this.taxNumber = taxNumber; }

    public Double getOutstandingBalance() { return outstandingBalance; }
    public void setOutstandingBalance(Double outstandingBalance) { this.outstandingBalance = outstandingBalance; }
}
