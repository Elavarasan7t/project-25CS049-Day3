package com.evnetwork.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "customer_invoices")
public class CustomerInvoice {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String invoiceNumber; // e.g. INV-2026-001

    private Long customerId;
    private String customerName;

    private Long salesOrderId;
    private String soNumber;

    private Long swapEventId;
    private String swapReceiptNumber;

    private LocalDateTime invoiceDate;
    private LocalDateTime dueDate;
    private Double amount;

    @Enumerated(EnumType.STRING)
    private InvoiceStatus status; // PENDING, PAID

    private LocalDateTime paymentDate;
    private String paymentReference;
    private String journalEntryReference;
    private String description;

    public enum InvoiceStatus {
        PENDING,
        PAID
    }

    public CustomerInvoice() {}

    public CustomerInvoice(String invoiceNumber, Long customerId, String customerName, Long salesOrderId, String soNumber, Long swapEventId, String swapReceiptNumber, LocalDateTime invoiceDate, LocalDateTime dueDate, Double amount, InvoiceStatus status, String description) {
        this.invoiceNumber = invoiceNumber;
        this.customerId = customerId;
        this.customerName = customerName;
        this.salesOrderId = salesOrderId;
        this.soNumber = soNumber;
        this.swapEventId = swapEventId;
        this.swapReceiptNumber = swapReceiptNumber;
        this.invoiceDate = invoiceDate;
        this.dueDate = dueDate;
        this.amount = amount;
        this.status = status;
        this.description = description;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getInvoiceNumber() { return invoiceNumber; }
    public void setInvoiceNumber(String invoiceNumber) { this.invoiceNumber = invoiceNumber; }

    public Long getCustomerId() { return customerId; }
    public void setCustomerId(Long customerId) { this.customerId = customerId; }

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }

    public Long getSalesOrderId() { return salesOrderId; }
    public void setSalesOrderId(Long salesOrderId) { this.salesOrderId = salesOrderId; }

    public String getSoNumber() { return soNumber; }
    public void setSoNumber(String soNumber) { this.soNumber = soNumber; }

    public Long getSwapEventId() { return swapEventId; }
    public void setSwapEventId(Long swapEventId) { this.swapEventId = swapEventId; }

    public String getSwapReceiptNumber() { return swapReceiptNumber; }
    public void setSwapReceiptNumber(String swapReceiptNumber) { this.swapReceiptNumber = swapReceiptNumber; }

    public LocalDateTime getInvoiceDate() { return invoiceDate; }
    public void setInvoiceDate(LocalDateTime invoiceDate) { this.invoiceDate = invoiceDate; }

    public LocalDateTime getDueDate() { return dueDate; }
    public void setDueDate(LocalDateTime dueDate) { this.dueDate = dueDate; }

    public Double getAmount() { return amount; }
    public void setAmount(Double amount) { this.amount = amount; }

    public InvoiceStatus getStatus() { return status; }
    public void setStatus(InvoiceStatus status) { this.status = status; }

    public LocalDateTime getPaymentDate() { return paymentDate; }
    public void setPaymentDate(LocalDateTime paymentDate) { this.paymentDate = paymentDate; }

    public String getPaymentReference() { return paymentReference; }
    public void setPaymentReference(String paymentReference) { this.paymentReference = paymentReference; }

    public String getJournalEntryReference() { return journalEntryReference; }
    public void setJournalEntryReference(String journalEntryReference) { this.journalEntryReference = journalEntryReference; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}
