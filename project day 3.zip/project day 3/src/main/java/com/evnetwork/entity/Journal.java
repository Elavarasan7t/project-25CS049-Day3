package com.evnetwork.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "journals")
public class Journal {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String code; // SJ (Sales), PJ (Purchase), CJ (Cash), BJ (Bank)

    @Column(nullable = false)
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private JournalType type; // SALES, PURCHASE, CASH, BANK

    private String description;

    public enum JournalType {
        SALES,
        PURCHASE,
        CASH,
        BANK
    }

    public Journal() {}

    public Journal(String code, String name, JournalType type, String description) {
        this.code = code;
        this.name = name;
        this.type = type;
        this.description = description;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public JournalType getType() { return type; }
    public void setType(JournalType type) { this.type = type; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}
