package com.evnetwork.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "journal_entries")
public class JournalEntry {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String entryNumber; // e.g. JE-2026-0001

    private LocalDateTime entryDate;
    private String journalCode; // SJ, PJ, CJ, BJ
    private String reference; // e.g. Swap Receipt, PO-001, INV-001
    private String description;
    private Double totalDebit;
    private Double totalCredit;
    private Boolean isBalanced;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    @JoinColumn(name = "journal_entry_id")
    private List<JournalLine> lines = new ArrayList<>();

    public JournalEntry() {}

    public JournalEntry(String entryNumber, LocalDateTime entryDate, String journalCode, String reference, String description) {
        this.entryNumber = entryNumber;
        this.entryDate = entryDate;
        this.journalCode = journalCode;
        this.reference = reference;
        this.description = description;
        this.totalDebit = 0.0;
        this.totalCredit = 0.0;
        this.isBalanced = true;
    }

    public void addLine(JournalLine line) {
        this.lines.add(line);
        recomputeTotals();
    }

    public void recomputeTotals() {
        double d = 0.0;
        double c = 0.0;
        for (JournalLine l : lines) {
            if (l.getDebitAmount() != null) d += l.getDebitAmount();
            if (l.getCreditAmount() != null) c += l.getCreditAmount();
        }
        this.totalDebit = Math.round(d * 100.0) / 100.0;
        this.totalCredit = Math.round(c * 100.0) / 100.0;
        this.isBalanced = Math.abs(this.totalDebit - this.totalCredit) < 0.01;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getEntryNumber() { return entryNumber; }
    public void setEntryNumber(String entryNumber) { this.entryNumber = entryNumber; }

    public LocalDateTime getEntryDate() { return entryDate; }
    public void setEntryDate(LocalDateTime entryDate) { this.entryDate = entryDate; }

    public String getJournalCode() { return journalCode; }
    public void setJournalCode(String journalCode) { this.journalCode = journalCode; }

    public String getReference() { return reference; }
    public void setReference(String reference) { this.reference = reference; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public Double getTotalDebit() { return totalDebit; }
    public void setTotalDebit(Double totalDebit) { this.totalDebit = totalDebit; }

    public Double getTotalCredit() { return totalCredit; }
    public void setTotalCredit(Double totalCredit) { this.totalCredit = totalCredit; }

    public Boolean getIsBalanced() { return isBalanced; }
    public void setIsBalanced(Boolean isBalanced) { this.isBalanced = isBalanced; }

    public List<JournalLine> getLines() { return lines; }
    public void setLines(List<JournalLine> lines) {
        this.lines = lines;
        recomputeTotals();
    }
}
