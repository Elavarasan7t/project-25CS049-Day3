package com.evnetwork.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "journal_lines")
public class JournalLine {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String accountCode;
    private String accountName;
    private Double debitAmount;
    private Double creditAmount;
    private String description;

    public JournalLine() {}

    public JournalLine(String accountCode, String accountName, Double debitAmount, Double creditAmount, String description) {
        this.accountCode = accountCode;
        this.accountName = accountName;
        this.debitAmount = debitAmount != null ? debitAmount : 0.0;
        this.creditAmount = creditAmount != null ? creditAmount : 0.0;
        this.description = description;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getAccountCode() { return accountCode; }
    public void setAccountCode(String accountCode) { this.accountCode = accountCode; }

    public String getAccountName() { return accountName; }
    public void setAccountName(String accountName) { this.accountName = accountName; }

    public Double getDebitAmount() { return debitAmount; }
    public void setDebitAmount(Double debitAmount) { this.debitAmount = debitAmount; }

    public Double getCreditAmount() { return creditAmount; }
    public void setCreditAmount(Double creditAmount) { this.creditAmount = creditAmount; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}
