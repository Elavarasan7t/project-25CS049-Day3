package com.evnetwork.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "payments")
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String paymentNumber; // PAY-2026-001

    private LocalDateTime paymentDate;

    @Enumerated(EnumType.STRING)
    private PaymentType type; // CUSTOMER_RECEIPT, VENDOR_PAYMENT

    private Long partnerId;
    private String partnerName;

    private String referenceType; // INVOICE, BILL
    private Long referenceId;
    private String referenceDocNumber;

    private Double amount;
    private String paymentMethod; // Bank Transfer, Direct Debit, Corporate Card
    private String bankAccountCode; // e.g. 1020
    private String journalEntryReference;

    public enum PaymentType {
        CUSTOMER_RECEIPT,
        VENDOR_PAYMENT
    }

    public Payment() {}

    public Payment(String paymentNumber, LocalDateTime paymentDate, PaymentType type, Long partnerId, String partnerName, String referenceType, Long referenceId, String referenceDocNumber, Double amount, String paymentMethod, String bankAccountCode) {
        this.paymentNumber = paymentNumber;
        this.paymentDate = paymentDate;
        this.type = type;
        this.partnerId = partnerId;
        this.partnerName = partnerName;
        this.referenceType = referenceType;
        this.referenceId = referenceId;
        this.referenceDocNumber = referenceDocNumber;
        this.amount = amount;
        this.paymentMethod = paymentMethod;
        this.bankAccountCode = bankAccountCode;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getPaymentNumber() { return paymentNumber; }
    public void setPaymentNumber(String paymentNumber) { this.paymentNumber = paymentNumber; }

    public LocalDateTime getPaymentDate() { return paymentDate; }
    public void setPaymentDate(LocalDateTime paymentDate) { this.paymentDate = paymentDate; }

    public PaymentType getType() { return type; }
    public void setType(PaymentType type) { this.type = type; }

    public Long getPartnerId() { return partnerId; }
    public void setPartnerId(Long partnerId) { this.partnerId = partnerId; }

    public String getPartnerName() { return partnerName; }
    public void setPartnerName(String partnerName) { this.partnerName = partnerName; }

    public String getReferenceType() { return referenceType; }
    public void setReferenceType(String referenceType) { this.referenceType = referenceType; }

    public Long getReferenceId() { return referenceId; }
    public void setReferenceId(Long referenceId) { this.referenceId = referenceId; }

    public String getReferenceDocNumber() { return referenceDocNumber; }
    public void setReferenceDocNumber(String referenceDocNumber) { this.referenceDocNumber = referenceDocNumber; }

    public Double getAmount() { return amount; }
    public void setAmount(Double amount) { this.amount = amount; }

    public String getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }

    public String getBankAccountCode() { return bankAccountCode; }
    public void setBankAccountCode(String bankAccountCode) { this.bankAccountCode = bankAccountCode; }

    public String getJournalEntryReference() { return journalEntryReference; }
    public void setJournalEntryReference(String journalEntryReference) { this.journalEntryReference = journalEntryReference; }
}
