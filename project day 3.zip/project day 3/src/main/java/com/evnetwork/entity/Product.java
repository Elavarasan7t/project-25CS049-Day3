package com.evnetwork.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "products")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String code;

    @Column(nullable = false)
    private String name;

    @Enumerated(EnumType.STRING)
    private ProductType type; // SERVICE, MODULE_LEASE, RECYCLING_SERVICE

    private Double standardPrice;
    private String unitOfMeasure; // session, month, module, kwh
    private String description;
    private String incomeAccountCode;
    private String expenseAccountCode;

    public enum ProductType {
        SERVICE,
        MODULE_LEASE,
        RECYCLING_SERVICE
    }

    public Product() {}

    public Product(String code, String name, ProductType type, Double standardPrice, String unitOfMeasure, String description, String incomeAccountCode, String expenseAccountCode) {
        this.code = code;
        this.name = name;
        this.type = type;
        this.standardPrice = standardPrice;
        this.unitOfMeasure = unitOfMeasure;
        this.description = description;
        this.incomeAccountCode = incomeAccountCode;
        this.expenseAccountCode = expenseAccountCode;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public ProductType getType() { return type; }
    public void setType(ProductType type) { this.type = type; }

    public Double getStandardPrice() { return standardPrice; }
    public void setStandardPrice(Double standardPrice) { this.standardPrice = standardPrice; }

    public String getUnitOfMeasure() { return unitOfMeasure; }
    public void setUnitOfMeasure(String unitOfMeasure) { this.unitOfMeasure = unitOfMeasure; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getIncomeAccountCode() { return incomeAccountCode; }
    public void setIncomeAccountCode(String incomeAccountCode) { this.incomeAccountCode = incomeAccountCode; }

    public String getExpenseAccountCode() { return expenseAccountCode; }
    public void setExpenseAccountCode(String expenseAccountCode) { this.expenseAccountCode = expenseAccountCode; }
}
