package com.evnetwork.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "purchase_orders")
public class PurchaseOrder {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String poNumber; // e.g. PO-REC-2026-001

    private LocalDateTime orderDate;
    private Long vendorId;
    private String vendorName;
    private String serviceType; // e.g. "Battery Module Circular Recycling"
    private Integer moduleCount;
    private Double unitPrice;
    private Double totalAmount;

    @Enumerated(EnumType.STRING)
    private POStatus status; // DRAFT, CONFIRMED, BILLED

    private String notes;

    public enum POStatus {
        DRAFT,
        CONFIRMED,
        BILLED
    }

    public PurchaseOrder() {}

    public PurchaseOrder(String poNumber, LocalDateTime orderDate, Long vendorId, String vendorName, String serviceType, Integer moduleCount, Double unitPrice, Double totalAmount, POStatus status, String notes) {
        this.poNumber = poNumber;
        this.orderDate = orderDate;
        this.vendorId = vendorId;
        this.vendorName = vendorName;
        this.serviceType = serviceType;
        this.moduleCount = moduleCount;
        this.unitPrice = unitPrice;
        this.totalAmount = totalAmount;
        this.status = status;
        this.notes = notes;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getPoNumber() { return poNumber; }
    public void setPoNumber(String poNumber) { this.poNumber = poNumber; }

    public LocalDateTime getOrderDate() { return orderDate; }
    public void setOrderDate(LocalDateTime orderDate) { this.orderDate = orderDate; }

    public Long getVendorId() { return vendorId; }
    public void setVendorId(Long vendorId) { this.vendorId = vendorId; }

    public String getVendorName() { return vendorName; }
    public void setVendorName(String vendorName) { this.vendorName = vendorName; }

    public String getServiceType() { return serviceType; }
    public void setServiceType(String serviceType) { this.serviceType = serviceType; }

    public Integer getModuleCount() { return moduleCount; }
    public void setModuleCount(Integer moduleCount) { this.moduleCount = moduleCount; }

    public Double getUnitPrice() { return unitPrice; }
    public void setUnitPrice(Double unitPrice) { this.unitPrice = unitPrice; }

    public Double getTotalAmount() { return totalAmount; }
    public void setTotalAmount(Double totalAmount) { this.totalAmount = totalAmount; }

    public POStatus getStatus() { return status; }
    public void setStatus(POStatus status) { this.status = status; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}
