package com.evnetwork.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "sales_orders")
public class SalesOrder {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String soNumber; // e.g. SO-2026-001

    private LocalDateTime orderDate;
    private Long customerId;
    private String customerName;

    private String planName; // Monthly Unlimited Fleet Swap, Tiered Fleet Access
    private Integer fleetVehicleCount;
    private Double monthlyRatePerVehicle;
    private Double totalAmount;

    @Enumerated(EnumType.STRING)
    private SOStatus status; // DRAFT, CONFIRMED, INVOICED

    private String notes;

    public enum SOStatus {
        DRAFT,
        CONFIRMED,
        INVOICED
    }

    public SalesOrder() {}

    public SalesOrder(String soNumber, LocalDateTime orderDate, Long customerId, String customerName, String planName, Integer fleetVehicleCount, Double monthlyRatePerVehicle, Double totalAmount, SOStatus status, String notes) {
        this.soNumber = soNumber;
        this.orderDate = orderDate;
        this.customerId = customerId;
        this.customerName = customerName;
        this.planName = planName;
        this.fleetVehicleCount = fleetVehicleCount;
        this.monthlyRatePerVehicle = monthlyRatePerVehicle;
        this.totalAmount = totalAmount;
        this.status = status;
        this.notes = notes;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getSoNumber() { return soNumber; }
    public void setSoNumber(String soNumber) { this.soNumber = soNumber; }

    public LocalDateTime getOrderDate() { return orderDate; }
    public void setOrderDate(LocalDateTime orderDate) { this.orderDate = orderDate; }

    public Long getCustomerId() { return customerId; }
    public void setCustomerId(Long customerId) { this.customerId = customerId; }

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }

    public String getPlanName() { return planName; }
    public void setPlanName(String planName) { this.planName = planName; }

    public Integer getFleetVehicleCount() { return fleetVehicleCount; }
    public void setFleetVehicleCount(Integer fleetVehicleCount) { this.fleetVehicleCount = fleetVehicleCount; }

    public Double getMonthlyRatePerVehicle() { return monthlyRatePerVehicle; }
    public void setMonthlyRatePerVehicle(Double monthlyRatePerVehicle) { this.monthlyRatePerVehicle = monthlyRatePerVehicle; }

    public Double getTotalAmount() { return totalAmount; }
    public void setTotalAmount(Double totalAmount) { this.totalAmount = totalAmount; }

    public SOStatus getStatus() { return status; }
    public void setStatus(SOStatus status) { this.status = status; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}
