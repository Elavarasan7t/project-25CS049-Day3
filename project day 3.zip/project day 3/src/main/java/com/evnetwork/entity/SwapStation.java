package com.evnetwork.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "swap_stations")
public class SwapStation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String stationCode;

    private String name;
    private String zoneCode; // ZONE-A, ZONE-B, ZONE-C
    private String location;
    private Integer totalBays;
    private Integer availablePacks;
    private Double gridPowerCostPerKwh; // e.g. 0.14 per kWh
    private Double swapServiceFee; // e.g. 35.00 per swap
    private String status; // OPERATIONAL, MAINTENANCE

    public SwapStation() {}

    public SwapStation(String stationCode, String name, String zoneCode, String location, Integer totalBays, Integer availablePacks, Double gridPowerCostPerKwh, Double swapServiceFee, String status) {
        this.stationCode = stationCode;
        this.name = name;
        this.zoneCode = zoneCode;
        this.location = location;
        this.totalBays = totalBays;
        this.availablePacks = availablePacks;
        this.gridPowerCostPerKwh = gridPowerCostPerKwh;
        this.swapServiceFee = swapServiceFee;
        this.status = status;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getStationCode() { return stationCode; }
    public void setStationCode(String stationCode) { this.stationCode = stationCode; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getZoneCode() { return zoneCode; }
    public void setZoneCode(String zoneCode) { this.zoneCode = zoneCode; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public Integer getTotalBays() { return totalBays; }
    public void setTotalBays(Integer totalBays) { this.totalBays = totalBays; }

    public Integer getAvailablePacks() { return availablePacks; }
    public void setAvailablePacks(Integer availablePacks) { this.availablePacks = availablePacks; }

    public Double getGridPowerCostPerKwh() { return gridPowerCostPerKwh; }
    public void setGridPowerCostPerKwh(Double gridPowerCostPerKwh) { this.gridPowerCostPerKwh = gridPowerCostPerKwh; }

    public Double getSwapServiceFee() { return swapServiceFee; }
    public void setSwapServiceFee(Double swapServiceFee) { this.swapServiceFee = swapServiceFee; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
