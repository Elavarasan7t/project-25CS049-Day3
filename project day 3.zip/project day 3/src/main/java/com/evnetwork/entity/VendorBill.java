package com.evnetwork.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "vendor_bills")
public class VendorBill {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String billNumber; // e.g. VB-2026-001

    private Long purchaseOrderId;
    private String poNumber;

    private Long vendorId;
    private String vendorName;

    private LocalDateTime billDate;
    private LocalDateTime dueDate;
    private Double amount;

    @Enumerated(EnumType.STRING)
    private BillStatus status; // PENDING, PAID

    private LocalDateTime paymentDate;
    private String paymentReference;
    private String journalEntryReference;

    public enum BillStatus {
        PENDING,
        PAID
    }

    public VendorBill() {}

    public VendorBill(String billNumber, Long purchaseOrderId, String poNumber, Long vendorId, String vendorName, LocalDateTime billDate, LocalDateTime dueDate, Double amount, BillStatus status) {
        this.billNumber = billNumber;
        this.purchaseOrderId = purchaseOrderId;
        this.poNumber = poNumber;
        this.vendorId = vendorId;
        this.vendorName = vendorName;
        this.billDate = billDate;
        this.dueDate = dueDate;
        this.amount = amount;
        this.status = status;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getBillNumber() { return billNumber; }
    public void setBillNumber(String billNumber) { this.billNumber = billNumber; }

    public Long getPurchaseOrderId() { return purchaseOrderId; }
    public void setPurchaseOrderId(Long purchaseOrderId) { this.purchaseOrderId = purchaseOrderId; }

    public String getPoNumber() { return poNumber; }
    public void setPoNumber(String poNumber) { this.poNumber = poNumber; }

    public Long getVendorId() { return vendorId; }
    public void setVendorId(Long vendorId) { this.vendorId = vendorId; }

    public String getVendorName() { return vendorName; }
    public void setVendorName(String vendorName) { this.vendorName = vendorName; }

    public LocalDateTime getBillDate() { return billDate; }
    public void setBillDate(LocalDateTime billDate) { this.billDate = billDate; }

    public LocalDateTime getDueDate() { return dueDate; }
    public void setDueDate(LocalDateTime dueDate) { this.dueDate = dueDate; }

    public Double getAmount() { return amount; }
    public void setAmount(Double amount) { this.amount = amount; }

    public BillStatus getStatus() { return status; }
    public void setStatus(BillStatus status) { this.status = status; }

    public LocalDateTime getPaymentDate() { return paymentDate; }
    public void setPaymentDate(LocalDateTime paymentDate) { this.paymentDate = paymentDate; }

    public String getPaymentReference() { return paymentReference; }
    public void setPaymentReference(String paymentReference) { this.paymentReference = paymentReference; }

    public String getJournalEntryReference() { return journalEntryReference; }
    public void setJournalEntryReference(String journalEntryReference) { this.journalEntryReference = journalEntryReference; }
}
