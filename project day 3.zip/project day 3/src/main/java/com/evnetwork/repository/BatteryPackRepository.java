package com.evnetwork.repository;

import com.evnetwork.entity.BatteryPack;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BatteryPackRepository extends JpaRepository<BatteryPack, Long> {
    Optional<BatteryPack> findBySerialNumber(String serialNumber);
    List<BatteryPack> findByStatus(BatteryPack.BatteryStatus status);
    List<BatteryPack> findByStationZone(String stationZone);
    List<BatteryPack> findByStateOfHealthLessThan(Double threshold);
    long countByStatus(BatteryPack.BatteryStatus status);
}
