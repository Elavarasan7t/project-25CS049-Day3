package com.evnetwork.repository;

import com.evnetwork.entity.BatterySwapEvent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BatterySwapEventRepository extends JpaRepository<BatterySwapEvent, Long> {
    Optional<BatterySwapEvent> findByReceiptNumber(String receiptNumber);
    List<BatterySwapEvent> findByZoneCode(String zoneCode);
    List<BatterySwapEvent> findByCustomerId(Long customerId);
    List<BatterySwapEvent> findByAutoRoutedToRecyclingTrue();
    List<BatterySwapEvent> findAllByOrderBySwapTimestampDesc();
}
