package com.evnetwork.repository;

import com.evnetwork.entity.Budget;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BudgetRepository extends JpaRepository<Budget, Long> {
    List<Budget> findByFiscalYear(String fiscalYear);
    Optional<Budget> findByZoneCodeAndFiscalYear(String zoneCode, String fiscalYear);
}
