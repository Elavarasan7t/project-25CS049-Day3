package com.evnetwork.repository;

import com.evnetwork.entity.JournalEntry;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface JournalEntryRepository extends JpaRepository<JournalEntry, Long> {
    Optional<JournalEntry> findByEntryNumber(String entryNumber);
    List<JournalEntry> findByJournalCode(String journalCode);
    List<JournalEntry> findAllByOrderByEntryDateDesc();
}
