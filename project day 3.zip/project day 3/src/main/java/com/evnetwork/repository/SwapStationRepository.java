package com.evnetwork.repository;

import com.evnetwork.entity.SwapStation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface SwapStationRepository extends JpaRepository<SwapStation, Long> {
    Optional<SwapStation> findByStationCode(String stationCode);
}
