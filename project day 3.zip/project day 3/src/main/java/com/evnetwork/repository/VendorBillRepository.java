package com.evnetwork.repository;

import com.evnetwork.entity.VendorBill;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface VendorBillRepository extends JpaRepository<VendorBill, Long> {
    Optional<VendorBill> findByBillNumber(String billNumber);
    List<VendorBill> findByStatus(VendorBill.BillStatus status);
    List<VendorBill> findAllByOrderByBillDateDesc();
}
