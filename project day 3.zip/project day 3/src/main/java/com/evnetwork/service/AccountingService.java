package com.evnetwork.service;

import com.evnetwork.entity.*;
import com.evnetwork.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class AccountingService {

    private final AccountRepository accountRepository;
    private final JournalRepository journalRepository;
    private final JournalEntryRepository journalEntryRepository;
    private final ContactRepository contactRepository;
    private final ProductRepository productRepository;
    private final PurchaseOrderRepository purchaseOrderRepository;
    private final VendorBillRepository vendorBillRepository;
    private final SalesOrderRepository salesOrderRepository;
    private final CustomerInvoiceRepository customerInvoiceRepository;
    private final PaymentRepository paymentRepository;

    public AccountingService(
            AccountRepository accountRepository,
            JournalRepository journalRepository,
            JournalEntryRepository journalEntryRepository,
            ContactRepository contactRepository,
            ProductRepository productRepository,
            PurchaseOrderRepository purchaseOrderRepository,
            VendorBillRepository vendorBillRepository,
            SalesOrderRepository salesOrderRepository,
            CustomerInvoiceRepository customerInvoiceRepository,
            PaymentRepository paymentRepository) {
        this.accountRepository = accountRepository;
        this.journalRepository = journalRepository;
        this.journalEntryRepository = journalEntryRepository;
        this.contactRepository = contactRepository;
        this.productRepository = productRepository;
        this.purchaseOrderRepository = purchaseOrderRepository;
        this.vendorBillRepository = vendorBillRepository;
        this.salesOrderRepository = salesOrderRepository;
        this.customerInvoiceRepository = customerInvoiceRepository;
        this.paymentRepository = paymentRepository;
    }

    public List<Account> getAllAccounts() {
        return accountRepository.findAll();
    }

    public Account getAccountByCode(String code) {
        return accountRepository.findByCode(code)
                .orElseThrow(() -> new IllegalArgumentException("Account code not found: " + code));
    }

    public Account saveAccount(Account account) {
        return accountRepository.save(account);
    }

    public List<Journal> getAllJournals() {
        return journalRepository.findAll();
    }

    public List<JournalEntry> getAllJournalEntries() {
        return journalEntryRepository.findAllByOrderByEntryDateDesc();
    }

    public JournalEntry recordJournalEntry(String journalCode, String reference, String description, List<JournalLine> lines) {
        String entryNumber = "JE-" + System.currentTimeMillis();
        JournalEntry entry = new JournalEntry(entryNumber, LocalDateTime.now(), journalCode, reference, description);

        for (JournalLine line : lines) {
            entry.addLine(line);
            // Update account balance
            Account acc = accountRepository.findByCode(line.getAccountCode()).orElse(null);
            if (acc != null) {
                double currentBal = acc.getBalance() != null ? acc.getBalance() : 0.0;
                if (acc.getType() == Account.AccountType.ASSET || acc.getType() == Account.AccountType.EXPENSE) {
                    currentBal += (line.getDebitAmount() - line.getCreditAmount());
                } else {
                    currentBal += (line.getCreditAmount() - line.getDebitAmount());
                }
                acc.setBalance(Math.round(currentBal * 100.0) / 100.0);
                accountRepository.save(acc);
            }
        }

        return journalEntryRepository.save(entry);
    }

    // Contact Master
    public List<Contact> getAllContacts() {
        return contactRepository.findAll();
    }

    public Contact saveContact(Contact contact) {
        return contactRepository.save(contact);
    }

    public Contact getContact(Long id) {
        return contactRepository.findById(id).orElse(null);
    }

    // Product Master
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    public Product saveProduct(Product product) {
        return productRepository.save(product);
    }

    // Purchase Order & Vendor Bill Flow
    public List<PurchaseOrder> getAllPurchaseOrders() {
        return purchaseOrderRepository.findAllByOrderByOrderDateDesc();
    }

    public PurchaseOrder createPurchaseOrder(PurchaseOrder po) {
        po.setOrderDate(LocalDateTime.now());
        if (po.getPoNumber() == null || po.getPoNumber().isBlank()) {
            po.setPoNumber("PO-" + System.currentTimeMillis());
        }
        if (po.getTotalAmount() == null && po.getUnitPrice() != null && po.getModuleCount() != null) {
            po.setTotalAmount(po.getUnitPrice() * po.getModuleCount());
        }
        if (po.getStatus() == null) {
            po.setStatus(PurchaseOrder.POStatus.CONFIRMED);
        }
        return purchaseOrderRepository.save(po);
    }

    public VendorBill convertPOToVendorBill(Long poId) {
        PurchaseOrder po = purchaseOrderRepository.findById(poId)
                .orElseThrow(() -> new IllegalArgumentException("PO not found: " + poId));

        po.setStatus(PurchaseOrder.POStatus.BILLED);
        purchaseOrderRepository.save(po);

        String billNum = "VB-" + System.currentTimeMillis();
        VendorBill bill = new VendorBill(
                billNum,
                po.getId(),
                po.getPoNumber(),
                po.getVendorId(),
                po.getVendorName(),
                LocalDateTime.now(),
                LocalDateTime.now().plusDays(30),
                po.getTotalAmount(),
                VendorBill.BillStatus.PENDING
        );

        // Record Journal Entry in Purchase Journal (PJ): Debit Recycling Costs (5020), Credit Manufacturer/Recycler Creditors (2010)
        JournalLine line1 = new JournalLine("5020", "Battery Recycling Costs", po.getTotalAmount(), 0.0, "Recycling PO: " + po.getPoNumber());
        JournalLine line2 = new JournalLine("2010", "Battery Manufacturer Creditors", 0.0, po.getTotalAmount(), "Payable for PO: " + po.getPoNumber());
        JournalEntry je = recordJournalEntry("PJ", billNum, "Vendor Bill for " + po.getVendorName(), List.of(line1, line2));

        bill.setJournalEntryReference(je.getEntryNumber());
        return vendorBillRepository.save(bill);
    }

    public List<VendorBill> getAllVendorBills() {
        return vendorBillRepository.findAllByOrderByBillDateDesc();
    }

    // Sales Order & Customer Invoice Flow
    public List<SalesOrder> getAllSalesOrders() {
        return salesOrderRepository.findAllByOrderByOrderDateDesc();
    }

    public SalesOrder createSalesOrder(SalesOrder so) {
        so.setOrderDate(LocalDateTime.now());
        if (so.getSoNumber() == null || so.getSoNumber().isBlank()) {
            so.setSoNumber("SO-" + System.currentTimeMillis());
        }
        if (so.getTotalAmount() == null && so.getFleetVehicleCount() != null && so.getMonthlyRatePerVehicle() != null) {
            so.setTotalAmount(so.getFleetVehicleCount() * so.getMonthlyRatePerVehicle());
        }
        if (so.getStatus() == null) {
            so.setStatus(SalesOrder.SOStatus.CONFIRMED);
        }
        return salesOrderRepository.save(so);
    }

    public CustomerInvoice convertSOToCustomerInvoice(Long soId) {
        SalesOrder so = salesOrderRepository.findById(soId)
                .orElseThrow(() -> new IllegalArgumentException("SO not found: " + soId));

        so.setStatus(SalesOrder.SOStatus.INVOICED);
        salesOrderRepository.save(so);

        String invNum = "INV-" + System.currentTimeMillis();
        CustomerInvoice invoice = new CustomerInvoice(
                invNum,
                so.getCustomerId(),
                so.getCustomerName(),
                so.getId(),
                so.getSoNumber(),
                null,
                null,
                LocalDateTime.now(),
                LocalDateTime.now().plusDays(15),
                so.getTotalAmount(),
                CustomerInvoice.InvoiceStatus.PENDING,
                "Fleet subscription for " + so.getPlanName()
        );

        // Record Journal Entry in Sales Journal (SJ): Debit Cash/Bank (1020) or Accounts Receivable, Credit Subscription Fees (4020)
        JournalLine line1 = new JournalLine("1020", "Cash/Bank", invoice.getAmount(), 0.0, "Subscription Receivables - " + so.getSoNumber());
        JournalLine line2 = new JournalLine("4020", "Subscription Fees", 0.0, invoice.getAmount(), "Subscription Revenue - " + so.getSoNumber());
        JournalEntry je = recordJournalEntry("SJ", invNum, "Invoice for " + so.getCustomerName(), List.of(line1, line2));

        invoice.setJournalEntryReference(je.getEntryNumber());
        return customerInvoiceRepository.save(invoice);
    }

    public List<CustomerInvoice> getAllCustomerInvoices() {
        return customerInvoiceRepository.findAllByOrderByInvoiceDateDesc();
    }

    public CustomerInvoice createInvoiceForSwap(BatterySwapEvent swap) {
        String invNum = "INV-SWAP-" + System.currentTimeMillis();
        CustomerInvoice invoice = new CustomerInvoice(
                invNum,
                swap.getCustomerId(),
                swap.getTaxiFleetName(),
                null,
                null,
                swap.getId(),
                swap.getReceiptNumber(),
                LocalDateTime.now(),
                LocalDateTime.now().plusDays(7),
                swap.getServiceFee(),
                CustomerInvoice.InvoiceStatus.PENDING,
                "Rapid swap session at " + swap.getStationName() + " (" + swap.getTaxiPlateNumber() + ")"
        );
        return customerInvoiceRepository.save(invoice);
    }

    // Bank Payment Settlement
    public Payment processPayment(Payment payment) {
        payment.setPaymentDate(LocalDateTime.now());
        if (payment.getPaymentNumber() == null || payment.getPaymentNumber().isBlank()) {
            payment.setPaymentNumber("PAY-" + System.currentTimeMillis());
        }

        if ("INVOICE".equalsIgnoreCase(payment.getReferenceType())) {
            CustomerInvoice invoice = customerInvoiceRepository.findById(payment.getReferenceId()).orElse(null);
            if (invoice != null) {
                invoice.setStatus(CustomerInvoice.InvoiceStatus.PAID);
                invoice.setPaymentDate(LocalDateTime.now());
                invoice.setPaymentReference(payment.getPaymentNumber());
                customerInvoiceRepository.save(invoice);

                // Debit Bank (1020), Credit Swap Revenues (4010)
                JournalLine line1 = new JournalLine("1020", "Cash/Bank", payment.getAmount(), 0.0, "Customer payment for " + invoice.getInvoiceNumber());
                JournalLine line2 = new JournalLine("4010", "Battery Swap Revenues", 0.0, payment.getAmount(), "Settlement of " + invoice.getInvoiceNumber());
                JournalEntry je = recordJournalEntry("BJ", payment.getPaymentNumber(), "Bank Settlement: " + invoice.getCustomerName(), List.of(line1, line2));
                payment.setJournalEntryReference(je.getEntryNumber());
            }
        } else if ("BILL".equalsIgnoreCase(payment.getReferenceType())) {
            VendorBill bill = vendorBillRepository.findById(payment.getReferenceId()).orElse(null);
            if (bill != null) {
                bill.setStatus(VendorBill.BillStatus.PAID);
                bill.setPaymentDate(LocalDateTime.now());
                bill.setPaymentReference(payment.getPaymentNumber());
                vendorBillRepository.save(bill);

                // Debit Manufacturer Creditors (2010), Credit Cash/Bank (1020)
                JournalLine line1 = new JournalLine("2010", "Battery Manufacturer Creditors", payment.getAmount(), 0.0, "Payment for " + bill.getBillNumber());
                JournalLine line2 = new JournalLine("1020", "Cash/Bank", 0.0, payment.getAmount(), "Bank disbursement for " + bill.getBillNumber());
                JournalEntry je = recordJournalEntry("BJ", payment.getPaymentNumber(), "Vendor Payment: " + bill.getVendorName(), List.of(line1, line2));
                payment.setJournalEntryReference(je.getEntryNumber());
            }
        }

        return paymentRepository.save(payment);
    }

    public List<Payment> getAllPayments() {
        return paymentRepository.findAllByOrderByPaymentDateDesc();
    }
}
