package com.evnetwork.service;

import com.evnetwork.entity.*;
import com.evnetwork.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;

@Service
@Transactional
public class BatteryService {

    public static final double RECYCLING_SOH_THRESHOLD = 70.0;

    private final BatteryPackRepository batteryPackRepository;
    private final SwapStationRepository swapStationRepository;
    private final BatterySwapEventRepository batterySwapEventRepository;
    private final ContactRepository contactRepository;
    private final AccountingService accountingService;

    public BatteryService(
            BatteryPackRepository batteryPackRepository,
            SwapStationRepository swapStationRepository,
            BatterySwapEventRepository batterySwapEventRepository,
            ContactRepository contactRepository,
            AccountingService accountingService) {
        this.batteryPackRepository = batteryPackRepository;
        this.swapStationRepository = swapStationRepository;
        this.batterySwapEventRepository = batterySwapEventRepository;
        this.contactRepository = contactRepository;
        this.accountingService = accountingService;
    }

    // Battery Pack Master Data (POST /api/batteries/packs)
    public BatteryPack registerBatteryPack(BatteryPack pack) {
        if (pack.getNominalCapacityKwh() == null) pack.setNominalCapacityKwh(75.0);
        if (pack.getStateOfHealth() == null) pack.setStateOfHealth(100.0);
        if (pack.getCycleCount() == null) pack.setCycleCount(0);
        if (pack.getAssetValuation() == null) pack.setAssetValuation(8500.0);
        if (pack.getManufacturingDate() == null) pack.setManufacturingDate(LocalDateTime.now());
        if (pack.getLastSwapTimestamp() == null) pack.setLastSwapTimestamp(LocalDateTime.now());
        if (pack.getStatus() == null) pack.setStatus(BatteryPack.BatteryStatus.CHARGING_AT_BAY);

        pack.setCurrentCapacityKwh((pack.getNominalCapacityKwh() * pack.getStateOfHealth()) / 100.0);

        BatteryPack saved = batteryPackRepository.save(pack);

        // Update Balance Sheet Asset: Swappable Battery Pack Inventory (Account 1010)
        Account invAcc = accountingService.getAccountByCode("1010");
        if (invAcc != null) {
            double current = invAcc.getBalance() != null ? invAcc.getBalance() : 0.0;
            invAcc.setBalance(current + saved.getAssetValuation());
            accountingService.saveAccount(invAcc);
        }

        return saved;
    }

    public List<BatteryPack> getAllBatteryPacks() {
        return batteryPackRepository.findAll();
    }

    public List<BatteryPack> getPacksByStatus(BatteryPack.BatteryStatus status) {
        return batteryPackRepository.findByStatus(status);
    }

    public List<BatteryPack> getDegradedPacks() {
        return batteryPackRepository.findByStateOfHealthLessThan(RECYCLING_SOH_THRESHOLD);
    }

    public Optional<BatteryPack> getPackById(Long id) {
        return batteryPackRepository.findById(id);
    }

    // Stations
    public List<SwapStation> getAllStations() {
        return swapStationRepository.findAll();
    }

    public SwapStation saveStation(SwapStation station) {
        return swapStationRepository.save(station);
    }

    public Optional<SwapStation> getStationById(Long id) {
        return swapStationRepository.findById(id);
    }

    // Ingest Swap Event (POST /api/batteries/swaps)
    public BatterySwapEvent processBatterySwap(
            Long stationId,
            Long customerId,
            String taxiPlateNumber,
            String driverName,
            Long depletedBatteryId,
            Long requestedInstalledBatteryId,
            Double customDepletedSoH) {

        SwapStation station = swapStationRepository.findById(stationId)
                .orElseThrow(() -> new IllegalArgumentException("Station not found: " + stationId));

        Contact customer = contactRepository.findById(customerId)
                .orElseThrow(() -> new IllegalArgumentException("Customer not found: " + customerId));

        BatteryPack depletedPack = batteryPackRepository.findById(depletedBatteryId)
                .orElseThrow(() -> new IllegalArgumentException("Depleted battery pack not found: " + depletedBatteryId));

        // Allow overriding SoH for interactive simulation or testing
        if (customDepletedSoH != null) {
            depletedPack.setStateOfHealth(customDepletedSoH);
        }

        // Increase cycle count for depleted pack
        int cycles = (depletedPack.getCycleCount() != null ? depletedPack.getCycleCount() : 0) + 1;
        depletedPack.setCycleCount(cycles);
        depletedPack.setLastSwapTimestamp(LocalDateTime.now());

        // Autonomous Circular Degradation Check: SoH < 70%
        boolean autoRouteToRecycle = depletedPack.getStateOfHealth() < RECYCLING_SOH_THRESHOLD;
        String recyclingReason = null;

        if (autoRouteToRecycle) {
            depletedPack.setStatus(BatteryPack.BatteryStatus.RETIRED_FOR_RECYCLING);
            recyclingReason = String.format("Degraded SoH (%.1f%% < %.1f%% threshold). Auto-flagged for Circular Hydrometallurgical Recycling.",
                    depletedPack.getStateOfHealth(), RECYCLING_SOH_THRESHOLD);
        } else {
            depletedPack.setStatus(BatteryPack.BatteryStatus.CHARGING_AT_BAY);
            depletedPack.setStationZone(station.getZoneCode());
        }
        batteryPackRepository.save(depletedPack);

        // Pick installed pack
        BatteryPack freshPack = null;
        if (requestedInstalledBatteryId != null) {
            freshPack = batteryPackRepository.findById(requestedInstalledBatteryId).orElse(null);
        }
        if (freshPack == null) {
            // Pick first available pack with SoH >= 80%
            List<BatteryPack> available = batteryPackRepository.findByStatus(BatteryPack.BatteryStatus.CHARGING_AT_BAY);
            for (BatteryPack p : available) {
                if (!p.getId().equals(depletedPack.getId()) && p.getStateOfHealth() >= 80.0) {
                    freshPack = p;
                    break;
                }
            }
        }
        if (freshPack == null) {
            // Fallback to any charging pack
            List<BatteryPack> anyCharging = batteryPackRepository.findByStatus(BatteryPack.BatteryStatus.CHARGING_AT_BAY);
            for (BatteryPack p : anyCharging) {
                if (!p.getId().equals(depletedPack.getId())) {
                    freshPack = p;
                    break;
                }
            }
        }

        if (freshPack != null) {
            freshPack.setStatus(BatteryPack.BatteryStatus.IN_SERVICE);
            freshPack.setLastSwapTimestamp(LocalDateTime.now());
            batteryPackRepository.save(freshPack);
        }

        // Energy delivered calculation
        double nominalCap = (freshPack != null && freshPack.getNominalCapacityKwh() != null) ? freshPack.getNominalCapacityKwh() : 75.0;
        double deliveredKwh = nominalCap * 0.85; // Approx 85% depth of discharge delivered
        double gridRate = (station.getGridPowerCostPerKwh() != null) ? station.getGridPowerCostPerKwh() : 0.14;
        double gridPowerCost = Math.round(deliveredKwh * gridRate * 100.0) / 100.0;
        double swapFee = (station.getSwapServiceFee() != null) ? station.getSwapServiceFee() : 38.50;

        // Build BatterySwapEvent
        String receiptNum = "RCPT-SWAP-" + System.currentTimeMillis();
        BatterySwapEvent swapEvent = new BatterySwapEvent();
        swapEvent.setReceiptNumber(receiptNum);
        swapEvent.setSwapTimestamp(LocalDateTime.now());
        swapEvent.setStationId(station.getId());
        swapEvent.setStationName(station.getName());
        swapEvent.setZoneCode(station.getZoneCode());
        swapEvent.setCustomerId(customer.getId());
        swapEvent.setTaxiFleetName(customer.getName());
        swapEvent.setTaxiPlateNumber(taxiPlateNumber != null ? taxiPlateNumber : "EV-TAXI-" + (100 + new Random().nextInt(900)));
        swapEvent.setDriverName(driverName != null ? driverName : "Fleet Driver");

        swapEvent.setDepletedBatteryId(depletedPack.getId());
        swapEvent.setDepletedBatterySerial(depletedPack.getSerialNumber());
        swapEvent.setDepletedBatterySoH(depletedPack.getStateOfHealth());

        if (freshPack != null) {
            swapEvent.setInstalledBatteryId(freshPack.getId());
            swapEvent.setInstalledBatterySerial(freshPack.getSerialNumber());
            swapEvent.setInstalledBatterySoH(freshPack.getStateOfHealth());
        }

        swapEvent.setEnergyDeliveredKwh(deliveredKwh);
        swapEvent.setServiceFee(swapFee);
        swapEvent.setGridElectricityCost(gridPowerCost);
        swapEvent.setAutoRoutedToRecycling(autoRouteToRecycle);
        swapEvent.setRecyclingReason(recyclingReason);
        swapEvent.setStatus("COMPLETED");

        BatterySwapEvent savedSwap = batterySwapEventRepository.save(swapEvent);

        // Record Balanced Double-Entry Journal Entry in Sales Journal (SJ)
        // Balancing Swap Session Revenue (Credit 4010) and Grid Power Cost (Debit 5010)
        JournalLine l1 = new JournalLine("1020", "Cash/Bank", swapFee, 0.0, "Swap payment receipt: " + receiptNum);
        JournalLine l2 = new JournalLine("4010", "Battery Swap Revenues", 0.0, swapFee, "Swap revenue: " + receiptNum);
        JournalLine l3 = new JournalLine("5010", "Grid Electricity Expenditures", gridPowerCost, 0.0, "Grid power consumed at " + station.getName());
        JournalLine l4 = new JournalLine("2020", "Grid Power Payables", 0.0, gridPowerCost, "Power utility payable for " + receiptNum);

        accountingService.recordJournalEntry("SJ", receiptNum, "Swap Session - " + customer.getName() + " (" + station.getName() + ")", List.of(l1, l2, l3, l4));

        // Generate customer invoice
        accountingService.createInvoiceForSwap(savedSwap);

        // If degraded, auto-create a draft Purchase Order for Battery Recycling Specialist
        if (autoRouteToRecycle) {
            List<Contact> recyclers = contactRepository.findByType(Contact.ContactType.VENDOR_RECYCLER);
            Contact recycler = recyclers.isEmpty() ? null : recyclers.get(0);
            if (recycler != null) {
                PurchaseOrder po = new PurchaseOrder(
                        "PO-REC-" + System.currentTimeMillis(),
                        LocalDateTime.now(),
                        recycler.getId(),
                        recycler.getName(),
                        "Circular Hydrometallurgical Recycling for Pack " + depletedPack.getSerialNumber(),
                        1,
                        650.0,
                        650.0,
                        PurchaseOrder.POStatus.CONFIRMED,
                        "Auto-generated for degraded pack " + depletedPack.getSerialNumber() + " (SoH: " + String.format("%.1f%%", depletedPack.getStateOfHealth()) + ")"
                );
                accountingService.createPurchaseOrder(po);
            }
        }

        return savedSwap;
    }

    public List<BatterySwapEvent> getAllSwapEvents() {
        return batterySwapEventRepository.findAllByOrderBySwapTimestampDesc();
    }

    // Telemetry Statistics
    public Map<String, Object> getTelemetryStats() {
        List<BatteryPack> all = batteryPackRepository.findAll();
        long inService = 0;
        long charging = 0;
        long retiredRecycling = 0;
        long inTransit = 0;

        int countAbove90 = 0;
        int count80to90 = 0;
        int count70to80 = 0;
        int countBelow70 = 0;

        double sumSoH = 0.0;
        for (BatteryPack p : all) {
            if (p.getStatus() == BatteryPack.BatteryStatus.IN_SERVICE) inService++;
            else if (p.getStatus() == BatteryPack.BatteryStatus.CHARGING_AT_BAY) charging++;
            else if (p.getStatus() == BatteryPack.BatteryStatus.RETIRED_FOR_RECYCLING) retiredRecycling++;
            else if (p.getStatus() == BatteryPack.BatteryStatus.IN_TRANSIT) inTransit++;

            double soh = p.getStateOfHealth() != null ? p.getStateOfHealth() : 0.0;
            sumSoH += soh;

            if (soh >= 90.0) countAbove90++;
            else if (soh >= 80.0) count80to90++;
            else if (soh >= 70.0) count70to80++;
            else countBelow70++;
        }

        double avgSoH = all.isEmpty() ? 0.0 : Math.round((sumSoH / all.size()) * 10.0) / 10.0;

        Map<String, Object> stats = new LinkedHashMap<>();
        stats.put("totalPacks", all.size());
        stats.put("inServiceCount", inService);
        stats.put("chargingBayCount", charging);
        stats.put("retiredRecyclingCount", retiredRecycling);
        stats.put("inTransitCount", inTransit);
        stats.put("averageSoH", avgSoH);
        stats.put("countAbove90", countAbove90);
        stats.put("count80to90", count80to90);
        stats.put("count70to80", count70to80);
        stats.put("countBelow70", countBelow70);
        stats.put("recyclingThreshold", RECYCLING_SOH_THRESHOLD);

        return stats;
    }
}
