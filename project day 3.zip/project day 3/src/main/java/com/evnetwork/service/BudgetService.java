package com.evnetwork.service;

import com.evnetwork.entity.AnalyticAccount;
import com.evnetwork.entity.BatterySwapEvent;
import com.evnetwork.entity.Budget;
import com.evnetwork.repository.AnalyticAccountRepository;
import com.evnetwork.repository.BatterySwapEventRepository;
import com.evnetwork.repository.BudgetRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
@Transactional
public class BudgetService {

    private final AnalyticAccountRepository analyticAccountRepository;
    private final BudgetRepository budgetRepository;
    private final BatterySwapEventRepository batterySwapEventRepository;

    public BudgetService(
            AnalyticAccountRepository analyticAccountRepository,
            BudgetRepository budgetRepository,
            BatterySwapEventRepository batterySwapEventRepository) {
        this.analyticAccountRepository = analyticAccountRepository;
        this.budgetRepository = budgetRepository;
        this.batterySwapEventRepository = batterySwapEventRepository;
    }

    public List<AnalyticAccount> getAllAnalyticAccounts() {
        return analyticAccountRepository.findAll();
    }

    public AnalyticAccount saveAnalyticAccount(AnalyticAccount account) {
        return analyticAccountRepository.save(account);
    }

    public List<Budget> getAllBudgets() {
        return budgetRepository.findAll();
    }

    public Budget saveBudget(Budget budget) {
        return budgetRepository.save(budget);
    }

    // Zone Budget vs Actual Performance Report
    public List<Map<String, Object>> getBudgetPerformanceReport() {
        List<Budget> budgets = budgetRepository.findAll();
        List<BatterySwapEvent> swaps = batterySwapEventRepository.findAll();

        List<Map<String, Object>> report = new ArrayList<>();

        for (Budget b : budgets) {
            String zone = b.getZoneCode();

            // Calculate actuals for this zone from swap telemetry
            double actualSwapRevenue = 0.0;
            double actualGridExpense = 0.0;
            double actualRecyclingExpense = 0.0;
            int zoneSwapCount = 0;
            int zoneRecycledPacks = 0;

            for (BatterySwapEvent s : swaps) {
                if (zone != null && zone.equalsIgnoreCase(s.getZoneCode())) {
                    zoneSwapCount++;
                    if (s.getServiceFee() != null) actualSwapRevenue += s.getServiceFee();
                    if (s.getGridElectricityCost() != null) actualGridExpense += s.getGridElectricityCost();
                    if (Boolean.TRUE.equals(s.getAutoRoutedToRecycling())) {
                        zoneRecycledPacks++;
                        actualRecyclingExpense += 650.0; // Standard unit cost per circular recycling batch
                    }
                }
            }

            actualSwapRevenue = Math.round(actualSwapRevenue * 100.0) / 100.0;
            actualGridExpense = Math.round(actualGridExpense * 100.0) / 100.0;
            actualRecyclingExpense = Math.round(actualRecyclingExpense * 100.0) / 100.0;

            double plannedRev = b.getPlannedSwapRevenue() != null ? b.getPlannedSwapRevenue() : 0.0;
            double plannedGrid = b.getPlannedGridExpense() != null ? b.getPlannedGridExpense() : 0.0;
            double plannedRecycle = b.getPlannedRecyclingExpense() != null ? b.getPlannedRecyclingExpense() : 0.0;

            double revenueVariance = Math.round((actualSwapRevenue - plannedRev) * 100.0) / 100.0;
            double gridExpenseVariance = Math.round((plannedGrid - actualGridExpense) * 100.0) / 100.0;
            double recyclingVariance = Math.round((plannedRecycle - actualRecyclingExpense) * 100.0) / 100.0;

            double gridBudgetUtilizationPct = plannedGrid > 0 ? Math.round((actualGridExpense / plannedGrid) * 1000.0) / 10.0 : 0.0;
            double recyclingBudgetUtilizationPct = plannedRecycle > 0 ? Math.round((actualRecyclingExpense / plannedRecycle) * 1000.0) / 10.0 : 0.0;

            Map<String, Object> zoneData = new LinkedHashMap<>();
            zoneData.put("budgetId", b.getId());
            zoneData.put("budgetName", b.getName());
            zoneData.put("zoneCode", zone);
            zoneData.put("zoneName", b.getAnalyticAccountName());
            zoneData.put("fiscalYear", b.getFiscalYear());
            zoneData.put("totalSwaps", zoneSwapCount);
            zoneData.put("recycledPacksCount", zoneRecycledPacks);

            zoneData.put("plannedRevenue", plannedRev);
            zoneData.put("actualRevenue", actualSwapRevenue);
            zoneData.put("revenueVariance", revenueVariance);

            zoneData.put("plannedGridExpense", plannedGrid);
            zoneData.put("actualGridExpense", actualGridExpense);
            zoneData.put("gridExpenseVariance", gridExpenseVariance);
            zoneData.put("gridBudgetUtilizationPct", gridBudgetUtilizationPct);

            zoneData.put("plannedRecyclingExpense", plannedRecycle);
            zoneData.put("actualRecyclingExpense", actualRecyclingExpense);
            zoneData.put("recyclingVariance", recyclingVariance);
            zoneData.put("recyclingBudgetUtilizationPct", recyclingBudgetUtilizationPct);

            double netOperatingActual = actualSwapRevenue - (actualGridExpense + actualRecyclingExpense);
            zoneData.put("netOperatingActual", Math.round(netOperatingActual * 100.0) / 100.0);

            report.add(zoneData);
        }

        return report;
    }
}
