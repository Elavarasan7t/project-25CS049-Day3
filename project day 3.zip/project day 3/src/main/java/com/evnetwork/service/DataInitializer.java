package com.evnetwork.service;

import com.evnetwork.entity.*;
import com.evnetwork.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

@Component
public class DataInitializer implements CommandLineRunner {

    private final AccountRepository accountRepository;
    private final JournalRepository journalRepository;
    private final ContactRepository contactRepository;
    private final ProductRepository productRepository;
    private final SwapStationRepository swapStationRepository;
    private final BatteryPackRepository batteryPackRepository;
    private final AnalyticAccountRepository analyticAccountRepository;
    private final BudgetRepository budgetRepository;
    private final PurchaseOrderRepository purchaseOrderRepository;
    private final SalesOrderRepository salesOrderRepository;
    private final BatterySwapEventRepository batterySwapEventRepository;

    public DataInitializer(
            AccountRepository accountRepository,
            JournalRepository journalRepository,
            ContactRepository contactRepository,
            ProductRepository productRepository,
            SwapStationRepository swapStationRepository,
            BatteryPackRepository batteryPackRepository,
            AnalyticAccountRepository analyticAccountRepository,
            BudgetRepository budgetRepository,
            PurchaseOrderRepository purchaseOrderRepository,
            SalesOrderRepository salesOrderRepository,
            BatterySwapEventRepository batterySwapEventRepository) {
        this.accountRepository = accountRepository;
        this.journalRepository = journalRepository;
        this.contactRepository = contactRepository;
        this.productRepository = productRepository;
        this.swapStationRepository = swapStationRepository;
        this.batteryPackRepository = batteryPackRepository;
        this.analyticAccountRepository = analyticAccountRepository;
        this.budgetRepository = budgetRepository;
        this.purchaseOrderRepository = purchaseOrderRepository;
        this.salesOrderRepository = salesOrderRepository;
        this.batterySwapEventRepository = batterySwapEventRepository;
    }

    @Override
    public void run(String... args) {
        if (accountRepository.count() > 0) return;

        // 1. Chart of Accounts Master
        accountRepository.save(new Account("1010", "Swappable Battery Pack Inventory", Account.AccountType.ASSET, "Current Asset", 198500.0));
        accountRepository.save(new Account("1015", "Charging Bay Infrastructure", Account.AccountType.ASSET, "Fixed Asset", 160000.0));
        accountRepository.save(new Account("1020", "Cash/Bank", Account.AccountType.ASSET, "Current Asset", 125400.0));

        accountRepository.save(new Account("2010", "Battery Manufacturer Creditors", Account.AccountType.LIABILITY, "Current Liability", 32000.0));
        accountRepository.save(new Account("2020", "Grid Power Payables", Account.AccountType.LIABILITY, "Current Liability", 11500.0));

        accountRepository.save(new Account("3010", "Clean Mobility Equity Capital", Account.AccountType.EQUITY, "Equity", 400000.0));

        accountRepository.save(new Account("4010", "Battery Swap Revenues", Account.AccountType.INCOME, "Operating Income", 48200.0));
        accountRepository.save(new Account("4020", "Subscription Fees", Account.AccountType.INCOME, "Operating Income", 36000.0));

        accountRepository.save(new Account("5010", "Grid Electricity Expenditures", Account.AccountType.EXPENSE, "Operating Expense", 21300.0));
        accountRepository.save(new Account("5020", "Battery Recycling Costs", Account.AccountType.EXPENSE, "Operating Expense", 9750.0));

        // 2. Journals Master
        journalRepository.save(new Journal("SJ", "Sales Journal", Journal.JournalType.SALES, "Swap session charges and taxi fleet subscriptions"));
        journalRepository.save(new Journal("PJ", "Purchase Journal", Journal.JournalType.PURCHASE, "Cell manufacturer orders and recycling vendor bills"));
        journalRepository.save(new Journal("CJ", "Cash Journal", Journal.JournalType.CASH, "Petty cash and kiosk coin/counter transactions"));
        journalRepository.save(new Journal("BJ", "Bank Journal", Journal.JournalType.BANK, "Direct debits, corporate bank transfers, and grid utility payouts"));

        // 3. Contact Master
        Contact taxi1 = contactRepository.save(new Contact("MetroVolt Green Cabs", Contact.ContactType.CUSTOMER, "dispatch@metrovolt.transit", "+1 (555) 019-2834", "Terminal 4 EV Hub, Metropolis", "TAX-MV-9821", 0.0));
        Contact taxi2 = contactRepository.save(new Contact("EcoRide City Fleet", Contact.ContactType.CUSTOMER, "fleet@ecoride.city", "+1 (555) 018-7741", "45 Green Horizon Ave, Capital City", "TAX-ER-4412", 0.0));
        Contact taxi3 = contactRepository.save(new Contact("Apex Express EV Taxis", Contact.ContactType.CUSTOMER, "operations@apextaxi.net", "+1 (555) 014-9982", "122 Airport Blvd, Metropolis", "TAX-AP-3390", 0.0));

        Contact vendorMfg = contactRepository.save(new Contact("CATL NextGen Cells Ltd", Contact.ContactType.VENDOR_MANUFACTURER, "oem@catl-cells.global", "+86 593 888 1234", "Energy Park Zone 3, Ningde", "VAT-CATL-8821", 0.0));
        Contact vendorRecycle = contactRepository.save(new Contact("EcoLithium Circular Recycling Specialists", Contact.ContactType.VENDOR_RECYCLER, "recovery@ecolithium.clean", "+1 (555) 017-5511", "Circular Loop 9, Cleantech Valley", "VAT-REC-1109", 0.0));

        // 4. Product Master
        productRepository.save(new Product("PROD-SWAP", "Rapid Battery Swap Session", Product.ProductType.SERVICE, 38.50, "session", "Instant automated 3-minute EV battery swap", "4010", null));
        productRepository.save(new Product("PROD-LEASE", "Battery Module Fleet Lease", Product.ProductType.MODULE_LEASE, 320.00, "month", "Monthly dedicated high-capacity pack allocation", "4020", null));
        productRepository.save(new Product("PROD-RECYC", "Cell Circular Recycling Service", Product.ProductType.RECYCLING_SERVICE, 650.00, "module", "Hydrometallurgical extraction and circular reclamation of lithium, cobalt, and nickel", null, "5020"));

        // 5. Swap Stations
        SwapStation st1 = swapStationRepository.save(new SwapStation("ST-CENTRAL", "Central Depot Hub", "ZONE-A", "Central Depot Plaza, Gate 2", 12, 9, 0.14, 38.50, "OPERATIONAL"));
        SwapStation st2 = swapStationRepository.save(new SwapStation("ST-TECH", "Tech Corridor Bay", "ZONE-B", "Cyber Ring Expressway, Exit 14", 8, 6, 0.15, 38.50, "OPERATIONAL"));
        SwapStation st3 = swapStationRepository.save(new SwapStation("ST-AIRPORT", "Airport Express Terminal", "ZONE-C", "Intl Terminal Commercial EV Lane", 16, 11, 0.13, 38.50, "OPERATIONAL"));
        SwapStation st4 = swapStationRepository.save(new SwapStation("ST-WEST", "Metro West Logistics Bay", "ZONE-D", "Westside Distribution Ring", 10, 7, 0.14, 38.50, "OPERATIONAL"));

        // 6. Battery Packs (including degraded modules with SoH < 70% to trigger circular recycling)
        batteryPackRepository.save(new BatteryPack("BP-LFP-9001", "LFP (Lithium Iron Phosphate)", 75.0, 96.5, 120, BatteryPack.BatteryStatus.IN_SERVICE, "ZONE-A", 8800.0));
        batteryPackRepository.save(new BatteryPack("BP-LFP-9002", "LFP (Lithium Iron Phosphate)", 75.0, 94.0, 180, BatteryPack.BatteryStatus.CHARGING_AT_BAY, "ZONE-A", 8700.0));
        batteryPackRepository.save(new BatteryPack("BP-NMC-8001", "NMC (Nickel Manganese Cobalt)", 82.0, 91.2, 290, BatteryPack.BatteryStatus.CHARGING_AT_BAY, "ZONE-A", 9100.0));
        batteryPackRepository.save(new BatteryPack("BP-NMC-8002", "NMC (Nickel Manganese Cobalt)", 82.0, 84.5, 480, BatteryPack.BatteryStatus.IN_SERVICE, "ZONE-B", 8500.0));
        batteryPackRepository.save(new BatteryPack("BP-LFP-9003", "LFP (Lithium Iron Phosphate)", 75.0, 81.0, 540, BatteryPack.BatteryStatus.CHARGING_AT_BAY, "ZONE-B", 8200.0));
        batteryPackRepository.save(new BatteryPack("BP-LFP-9004", "LFP (Lithium Iron Phosphate)", 75.0, 74.5, 780, BatteryPack.BatteryStatus.CHARGING_AT_BAY, "ZONE-C", 7800.0));
        batteryPackRepository.save(new BatteryPack("BP-NMC-8003", "NMC (Nickel Manganese Cobalt)", 82.0, 71.8, 890, BatteryPack.BatteryStatus.CHARGING_AT_BAY, "ZONE-C", 7600.0));

        // Degraded packs auto-flagged for recycling (< 70% SoH)
        batteryPackRepository.save(new BatteryPack("BP-NMC-7001", "NMC (Nickel Manganese Cobalt)", 82.0, 68.2, 1140, BatteryPack.BatteryStatus.RETIRED_FOR_RECYCLING, "ZONE-A", 6500.0));
        batteryPackRepository.save(new BatteryPack("BP-LFP-6002", "LFP (Lithium Iron Phosphate)", 75.0, 66.4, 1280, BatteryPack.BatteryStatus.RETIRED_FOR_RECYCLING, "ZONE-C", 6200.0));
        batteryPackRepository.save(new BatteryPack("BP-NMC-7002", "NMC (Nickel Manganese Cobalt)", 82.0, 64.1, 1390, BatteryPack.BatteryStatus.RETIRED_FOR_RECYCLING, "ZONE-B", 6000.0));

        // 7. Analytic Accounts (Swap Station Zones)
        analyticAccountRepository.save(new AnalyticAccount("ZONE-A", "Central Depot Zone A", "High-density downtown commuter & commercial taxi core", true));
        analyticAccountRepository.save(new AnalyticAccount("ZONE-B", "Tech Corridor Zone B", "Suburban tech campuses and rapid highway transit link", true));
        analyticAccountRepository.save(new AnalyticAccount("ZONE-C", "Airport Express Zone C", "24/7 high-throughput airport taxi & shuttle network", true));
        analyticAccountRepository.save(new AnalyticAccount("ZONE-D", "Metro West Zone D", "Inter-city freight logistics and outer transit depot", true));

        // 8. Operational Budgets (Allocates planned revenue & expenses per zone)
        budgetRepository.save(new Budget("FY2026 Zone A Operational Budget", "2026", "ZONE-A", "Central Depot Zone A", 32000.0, 9500.0, 4500.0));
        budgetRepository.save(new Budget("FY2026 Zone B Operational Budget", "2026", "ZONE-B", "Tech Corridor Zone B", 22000.0, 6800.0, 3200.0));
        budgetRepository.save(new Budget("FY2026 Zone C Operational Budget", "2026", "ZONE-C", "Airport Express Zone C", 45000.0, 14000.0, 5800.0));
        budgetRepository.save(new Budget("FY2026 Zone D Operational Budget", "2026", "ZONE-D", "Metro West Zone D", 18000.0, 5200.0, 2600.0));

        // 9. Initial Sample Swap Events
        BatterySwapEvent ev1 = new BatterySwapEvent();
        ev1.setReceiptNumber("RCPT-SWAP-INIT-101");
        ev1.setSwapTimestamp(LocalDateTime.now().minusHours(3));
        ev1.setStationId(st1.getId());
        ev1.setStationName(st1.getName());
        ev1.setZoneCode("ZONE-A");
        ev1.setCustomerId(taxi1.getId());
        ev1.setTaxiFleetName(taxi1.getName());
        ev1.setTaxiPlateNumber("MV-TX-701");
        ev1.setDriverName("Marcus Vance");
        ev1.setDepletedBatteryId(2L);
        ev1.setDepletedBatterySerial("BP-LFP-9002");
        ev1.setDepletedBatterySoH(94.0);
        ev1.setInstalledBatteryId(1L);
        ev1.setInstalledBatterySerial("BP-LFP-9001");
        ev1.setInstalledBatterySoH(96.5);
        ev1.setEnergyDeliveredKwh(63.75);
        ev1.setServiceFee(38.50);
        ev1.setGridElectricityCost(8.93);
        ev1.setAutoRoutedToRecycling(false);
        ev1.setStatus("COMPLETED");
        batterySwapEventRepository.save(ev1);

        BatterySwapEvent ev2 = new BatterySwapEvent();
        ev2.setReceiptNumber("RCPT-SWAP-INIT-102");
        ev2.setSwapTimestamp(LocalDateTime.now().minusHours(1));
        ev2.setStationId(st3.getId());
        ev2.setStationName(st3.getName());
        ev2.setZoneCode("ZONE-C");
        ev2.setCustomerId(taxi3.getId());
        ev2.setTaxiFleetName(taxi3.getName());
        ev2.setTaxiPlateNumber("AP-TX-419");
        ev2.setDriverName("Sarah Chen");
        ev2.setDepletedBatteryId(9L);
        ev2.setDepletedBatterySerial("BP-LFP-6002");
        ev2.setDepletedBatterySoH(66.4);
        ev2.setInstalledBatteryId(6L);
        ev2.setInstalledBatterySerial("BP-LFP-9004");
        ev2.setInstalledBatterySoH(74.5);
        ev2.setEnergyDeliveredKwh(63.75);
        ev2.setServiceFee(38.50);
        ev2.setGridElectricityCost(8.29);
        ev2.setAutoRoutedToRecycling(true);
        ev2.setRecyclingReason("Degraded SoH (66.4% < 70.0% threshold). Auto-flagged for Circular Hydrometallurgical Recycling.");
        ev2.setStatus("COMPLETED");
        batterySwapEventRepository.save(ev2);

        // 10. Sample Purchase Order for Recycling
        PurchaseOrder samplePo = new PurchaseOrder(
                "PO-REC-2026-001",
                LocalDateTime.now().minusDays(2),
                vendorRecycle.getId(),
                vendorRecycle.getName(),
                "Battery Module Circular Recycling Batch 4",
                3,
                650.0,
                1950.0,
                PurchaseOrder.POStatus.CONFIRMED,
                "Batch recycling of retired packs BP-NMC-7001, BP-LFP-6002, BP-NMC-7002"
        );
        purchaseOrderRepository.save(samplePo);

        // 11. Sample Sales Order
        SalesOrder sampleSo = new SalesOrder(
                "SO-2026-001",
                LocalDateTime.now().minusDays(5),
                taxi1.getId(),
                taxi1.getName(),
                "Monthly Unlimited Metro Fleet Swap Package",
                25,
                480.0,
                12000.0,
                SalesOrder.SOStatus.CONFIRMED,
                "Monthly commercial subscription for 25 fleet cabs"
        );
        salesOrderRepository.save(sampleSo);
    }
}
