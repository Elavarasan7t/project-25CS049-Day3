package com.evnetwork.service;

import com.evnetwork.entity.Account;
import com.evnetwork.repository.AccountRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;

@Service
@Transactional(readOnly = true)
public class ReportService {

    private final AccountRepository accountRepository;
    private final BudgetService budgetService;

    public ReportService(AccountRepository accountRepository, BudgetService budgetService) {
        this.accountRepository = accountRepository;
        this.budgetService = budgetService;
    }

    // 1. Balance Sheet
    public Map<String, Object> getBalanceSheet() {
        List<Account> assets = accountRepository.findByType(Account.AccountType.ASSET);
        List<Account> liabilities = accountRepository.findByType(Account.AccountType.LIABILITY);
        List<Account> equities = accountRepository.findByType(Account.AccountType.EQUITY);

        double totalAssets = 0.0;
        for (Account a : assets) {
            totalAssets += (a.getBalance() != null ? a.getBalance() : 0.0);
        }

        double totalLiabilities = 0.0;
        for (Account l : liabilities) {
            totalLiabilities += (l.getBalance() != null ? l.getBalance() : 0.0);
        }

        double totalEquity = 0.0;
        for (Account e : equities) {
            totalEquity += (e.getBalance() != null ? e.getBalance() : 0.0);
        }

        // Net P&L (retained earnings surplus) balances the sheet
        double retainedSurplus = Math.round((totalAssets - totalLiabilities - totalEquity) * 100.0) / 100.0;

        Map<String, Object> sheet = new LinkedHashMap<>();
        sheet.put("generatedAt", LocalDateTime.now());
        sheet.put("assets", assets);
        sheet.put("totalAssets", Math.round(totalAssets * 100.0) / 100.0);
        sheet.put("liabilities", liabilities);
        sheet.put("totalLiabilities", Math.round(totalLiabilities * 100.0) / 100.0);
        sheet.put("equity", equities);
        sheet.put("retainedSurplus", retainedSurplus);
        sheet.put("totalLiabilitiesAndEquity", Math.round((totalLiabilities + totalEquity + retainedSurplus) * 100.0) / 100.0);
        sheet.put("isBalanced", Math.abs(totalAssets - (totalLiabilities + totalEquity + retainedSurplus)) < 0.05);

        return sheet;
    }

    // 2. Profit & Loss Account
    public Map<String, Object> getProfitAndLoss() {
        List<Account> incomeAccs = accountRepository.findByType(Account.AccountType.INCOME);
        List<Account> expenseAccs = accountRepository.findByType(Account.AccountType.EXPENSE);

        double totalIncome = 0.0;
        for (Account a : incomeAccs) {
            totalIncome += (a.getBalance() != null ? a.getBalance() : 0.0);
        }

        double totalExpense = 0.0;
        for (Account a : expenseAccs) {
            totalExpense += (a.getBalance() != null ? a.getBalance() : 0.0);
        }

        totalIncome = Math.round(totalIncome * 100.0) / 100.0;
        totalExpense = Math.round(totalExpense * 100.0) / 100.0;
        double netOperatingIncome = Math.round((totalIncome - totalExpense) * 100.0) / 100.0;
        double operatingMarginPct = totalIncome > 0 ? Math.round((netOperatingIncome / totalIncome) * 1000.0) / 10.0 : 0.0;

        Map<String, Object> pnl = new LinkedHashMap<>();
        pnl.put("generatedAt", LocalDateTime.now());
        pnl.put("incomeAccounts", incomeAccs);
        pnl.put("totalIncome", totalIncome);
        pnl.put("expenseAccounts", expenseAccs);
        pnl.put("totalExpenses", totalExpense);
        pnl.put("netOperatingIncome", netOperatingIncome);
        pnl.put("operatingMarginPct", operatingMarginPct);
        pnl.put("status", netOperatingIncome >= 0 ? "PROFITABLE" : "OPERATING_DEFICIT");

        return pnl;
    }

    // 3. Station Budget Report
    public List<Map<String, Object>> getBudgetReport() {
        return budgetService.getBudgetPerformanceReport();
    }
}
