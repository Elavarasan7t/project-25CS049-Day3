/**
 * Public EV Fleet Battery Swapping & Circular Recycling Network
 * Frontend Application Logic & API Client
 */

const API_BASE = '';

// App State
let state = {
  stations: [],
  contacts: [],
  products: [],
  packs: [],
  telemetry: {},
  swaps: [],
  coa: [],
  journals: [],
  journalEntries: [],
  purchaseOrders: [],
  vendorBills: [],
  salesOrders: [],
  customerInvoices: [],
  payments: [],
  budgetPerformance: [],
  balanceSheet: {},
  pnl: {}
};

// Initialize Application on DOM Ready
document.addEventListener('DOMContentLoaded', () => {
  initNavigation();
  initModals();
  initSwapKioskEvents();
  loadAllData();
});

// ==========================================
// NAVIGATION & VIEW SWITCHING
// ==========================================
function initNavigation() {
  const navItems = document.querySelectorAll('.nav-item');
  const views = document.querySelectorAll('.tab-view');
  const viewTitle = document.getElementById('current-view-title');
  const viewDesc = document.getElementById('current-view-desc');
  const actorBadge = document.getElementById('current-actor-badge');

  const metaMap = {
    'view-director': {
      title: 'Battery Network Operations Hub',
      desc: 'Real-time telemetry, fleet health degradation curves, and station bay monitoring.',
      actor: 'Admin (Network Director)'
    },
    'view-driver': {
      title: 'Automated Station Swap Bay',
      desc: 'Driver self-service kiosk with automated SoH diagnostics and instant circular auto-route.',
      actor: 'Fleet Driver / Station Kiosk'
    },
    'view-accountant': {
      title: 'Accounting, Master Data & Invoicing',
      desc: 'Manage Contacts, Chart of Accounts, Purchase Orders, Vendor Bills, and Invoices.',
      actor: 'Invoicing User (Network Accountant)'
    },
    'view-circular': {
      title: 'Circular Battery Recycling & Station Budgets',
      desc: 'Degraded module (<70% SoH) reclamation pipeline and station zone operational budget performance.',
      actor: 'System / Sustainability Officer'
    },
    'view-reports': {
      title: 'Financial Statements & Audits',
      desc: 'Double-entry Balance Sheet, Profit & Loss Statement, and Zone Variance Reports.',
      actor: 'Auditor / Executive'
    }
  };

  navItems.forEach(item => {
    item.addEventListener('click', () => {
      const targetView = item.getAttribute('data-view');
      navItems.forEach(n => n.classList.remove('active'));
      views.forEach(v => v.classList.remove('active'));

      item.classList.add('active');
      const activePanel = document.getElementById(targetView);
      if (activePanel) activePanel.classList.add('active');

      if (metaMap[targetView]) {
        viewTitle.textContent = metaMap[targetView].title;
        viewDesc.textContent = metaMap[targetView].desc;
        actorBadge.innerHTML = `<i class="fa-solid fa-user-shield"></i> <span>${metaMap[targetView].actor}</span>`;
      }

      // Refresh data on view switch
      if (targetView === 'view-reports') loadFinancialReports();
      if (targetView === 'view-circular') loadCircularAndBudgetView();
      if (targetView === 'view-accountant') loadAccountingView();
    });
  });

  // Inner accounting sub-tabs
  const subTabBtns = document.querySelectorAll('.sub-tab-btn');
  subTabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetSection = btn.getAttribute('data-subtab');
      subTabBtns.forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.accounting-subview').forEach(s => s.style.display = 'none');

      btn.classList.add('active');
      const targetEl = document.getElementById(targetSection);
      if (targetEl) targetEl.style.display = 'block';
    });
  });
}

// ==========================================
// DATA FETCHING & SYNCHRONIZATION
// ==========================================
async function loadAllData() {
  try {
    await Promise.all([
      fetchStations(),
      fetchContacts(),
      fetchProducts(),
      fetchBatteryPacks(),
      fetchTelemetryStats(),
      fetchSwapEvents(),
      fetchChartOfAccounts(),
      fetchJournals(),
      fetchJournalEntries(),
      fetchTransactions()
    ]);

    populateSwapKioskOptions();
    renderDirectorDashboard();
    renderAccountingView();
    renderCircularRecyclingView();
  } catch (err) {
    console.error('Error fetching data:', err);
  }
}

async function fetchStations() {
  const res = await fetch(`${API_BASE}/api/batteries/stations`);
  state.stations = await res.json();
  renderStationsTable();
}

async function fetchContacts() {
  const res = await fetch(`${API_BASE}/api/contacts`);
  state.contacts = await res.json();
  renderContactsTable();
}

async function fetchProducts() {
  const res = await fetch(`${API_BASE}/api/products`);
  state.products = await res.json();
  renderProductsTable();
}

async function fetchBatteryPacks() {
  const res = await fetch(`${API_BASE}/api/batteries/packs`);
  state.packs = await res.json();
  renderPacksTable();
}

async function fetchTelemetryStats() {
  const res = await fetch(`${API_BASE}/api/batteries/telemetry/stats`);
  state.telemetry = await res.json();
  renderTelemetryMetrics();
}

async function fetchSwapEvents() {
  const res = await fetch(`${API_BASE}/api/batteries/swaps`);
  state.swaps = await res.json();
  renderRecentSwapsTable();
}

async function fetchChartOfAccounts() {
  const res = await fetch(`${API_BASE}/api/accounting/coa`);
  state.coa = await res.json();
  renderChartOfAccounts();
}

async function fetchJournals() {
  const res = await fetch(`${API_BASE}/api/accounting/journals`);
  state.journals = await res.json();
}

async function fetchJournalEntries() {
  const res = await fetch(`${API_BASE}/api/accounting/journal-entries`);
  state.journalEntries = await res.json();
  renderJournalEntriesTable();
}

async function fetchTransactions() {
  const [poRes, billRes, soRes, invRes, payRes] = await Promise.all([
    fetch(`${API_BASE}/api/transactions/purchase-orders`),
    fetch(`${API_BASE}/api/transactions/vendor-bills`),
    fetch(`${API_BASE}/api/transactions/sales-orders`),
    fetch(`${API_BASE}/api/transactions/customer-invoices`),
    fetch(`${API_BASE}/api/transactions/payments`)
  ]);

  state.purchaseOrders = await poRes.json();
  state.vendorBills = await billRes.json();
  state.salesOrders = await soRes.json();
  state.customerInvoices = await invRes.json();
  state.payments = await payRes.json();

  renderPurchaseOrdersTable();
  renderVendorBillsTable();
  renderSalesOrdersTable();
  renderCustomerInvoicesTable();
  renderPaymentsTable();
}

// ==========================================
// RENDER VIEWS & DASHBOARDS
// ==========================================
function renderTelemetryMetrics() {
  const t = state.telemetry;
  if (!t) return;

  const elTotal = document.getElementById('kpi-total-packs');
  const elInService = document.getElementById('kpi-in-service');
  const elCharging = document.getElementById('kpi-charging');
  const elRecycled = document.getElementById('kpi-recycled');
  const elAvgSoH = document.getElementById('kpi-avg-soh');

  if (elTotal) elTotal.textContent = t.totalPacks || 0;
  if (elInService) elInService.textContent = t.inServiceCount || 0;
  if (elCharging) elCharging.textContent = t.chargingBayCount || 0;
  if (elRecycled) elRecycled.textContent = t.retiredRecyclingCount || 0;
  if (elAvgSoH) elAvgSoH.textContent = `${t.averageSoH || 0}%`;

  // SoH Distribution breakdown bars
  const total = t.totalPacks || 1;
  const p90 = Math.round(((t.countAbove90 || 0) / total) * 100);
  const p80 = Math.round(((t.count80to90 || 0) / total) * 100);
  const p70 = Math.round(((t.count70to80 || 0) / total) * 100);
  const pCrit = Math.round(((t.countBelow70 || 0) / total) * 100);

  const bar90 = document.getElementById('bar-soh-90');
  const bar80 = document.getElementById('bar-soh-80');
  const bar70 = document.getElementById('bar-soh-70');
  const barCrit = document.getElementById('bar-soh-crit');

  if (bar90) bar90.style.width = `${p90}%`;
  if (bar80) bar80.style.width = `${p80}%`;
  if (bar70) bar70.style.width = `${p70}%`;
  if (barCrit) barCrit.style.width = `${pCrit}%`;

  document.getElementById('lbl-soh-90').textContent = `${t.countAbove90 || 0} packs (${p90}%)`;
  document.getElementById('lbl-soh-80').textContent = `${t.count80to90 || 0} packs (${p80}%)`;
  document.getElementById('lbl-soh-70').textContent = `${t.count70to80 || 0} packs (${p70}%)`;
  document.getElementById('lbl-soh-crit').textContent = `${t.countBelow70 || 0} packs (${pCrit}%)`;
}

function renderDirectorDashboard() {
  renderPacksTable();
  renderStationsTable();
  renderRecentSwapsTable();
}

function renderPacksTable() {
  const tbody = document.getElementById('packs-table-body');
  if (!tbody) return;

  tbody.innerHTML = '';
  state.packs.forEach(pack => {
    const tr = document.createElement('tr');

    let statusBadge = '';
    if (pack.status === 'IN_SERVICE') {
      statusBadge = `<span class="badge badge-cyan"><i class="fa-solid fa-car"></i> In Service</span>`;
    } else if (pack.status === 'CHARGING_AT_BAY') {
      statusBadge = `<span class="badge badge-emerald"><i class="fa-solid fa-bolt"></i> Charging</span>`;
    } else if (pack.status === 'RETIRED_FOR_RECYCLING') {
      statusBadge = `<span class="badge badge-rose"><i class="fa-solid fa-recycle"></i> Circular Recycled</span>`;
    } else {
      statusBadge = `<span class="badge badge-amber">${pack.status}</span>`;
    }

    let sohClass = 'soh-optimal';
    if (pack.stateOfHealth < 70) sohClass = 'soh-degraded';
    else if (pack.stateOfHealth < 80) sohClass = 'soh-moderate';
    else if (pack.stateOfHealth < 90) sohClass = 'soh-good';

    tr.innerHTML = `
      <td><strong>${pack.serialNumber}</strong></td>
      <td>${pack.chemistry || 'LFP'}</td>
      <td>${pack.nominalCapacityKwh} kWh</td>
      <td>
        <div style="display: flex; justify-content: space-between; font-size: 0.8rem; font-weight: 600;">
          <span>${pack.stateOfHealth.toFixed(1)}%</span>
          <span style="color: ${pack.stateOfHealth < 70 ? 'var(--rose)' : 'var(--text-muted)'}">
            ${pack.stateOfHealth < 70 ? 'RECYCLE REQ' : 'HEALTHY'}
          </span>
        </div>
        <div class="soh-bar-bg">
          <div class="soh-bar-fill ${sohClass}" style="width: ${Math.min(pack.stateOfHealth, 100)}%;"></div>
        </div>
      </td>
      <td>${pack.cycleCount || 0}</td>
      <td>${statusBadge}</td>
      <td><span class="badge badge-emerald">${pack.stationZone || 'ZONE-A'}</span></td>
      <td>$${(pack.assetValuation || 0).toLocaleString()}</td>
    `;
    tbody.appendChild(tr);
  });
}

function renderStationsTable() {
  const tbody = document.getElementById('stations-table-body');
  if (!tbody) return;

  tbody.innerHTML = '';
  state.stations.forEach(st => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>${st.stationCode}</strong></td>
      <td>${st.name}</td>
      <td><span class="badge badge-cyan">${st.zoneCode}</span></td>
      <td>${st.location}</td>
      <td><strong>${st.availablePacks}</strong> / ${st.totalBays} Bays</td>
      <td>$${(st.gridPowerCostPerKwh || 0.14).toFixed(2)} / kWh</td>
      <td>$${(st.swapServiceFee || 38.50).toFixed(2)}</td>
      <td><span class="badge badge-emerald"><i class="fa-solid fa-circle-check"></i> ${st.status}</span></td>
    `;
    tbody.appendChild(tr);
  });
}

function renderRecentSwapsTable() {
  const tbody = document.getElementById('recent-swaps-table-body');
  if (!tbody) return;

  tbody.innerHTML = '';
  state.swaps.slice(0, 8).forEach(sw => {
    const tr = document.createElement('tr');

    const recycleFlag = sw.autoRoutedToRecycling
      ? `<span class="badge badge-rose"><i class="fa-solid fa-triangle-exclamation"></i> Auto-Recycled (<70%)</span>`
      : `<span class="badge badge-emerald"><i class="fa-solid fa-check"></i> Healthy (Recharging)</span>`;

    tr.innerHTML = `
      <td><code>${sw.receiptNumber}</code></td>
      <td>${formatDate(sw.swapTimestamp)}</td>
      <td>${sw.stationName}</td>
      <td><strong>${sw.taxiFleetName}</strong> (${sw.taxiPlateNumber})</td>
      <td>${sw.depletedBatterySerial} <small>(${sw.depletedBatterySoH.toFixed(1)}% SoH)</small></td>
      <td>${sw.installedBatterySerial || 'N/A'} <small>(${sw.installedBatterySoH ? sw.installedBatterySoH.toFixed(1) + '%' : 'N/A'})</small></td>
      <td><strong>${(sw.energyDeliveredKwh || 0).toFixed(1)} kWh</strong></td>
      <td>$${(sw.serviceFee || 0).toFixed(2)}</td>
      <td>${recycleFlag}</td>
    `;
    tbody.appendChild(tr);
  });
}

// ==========================================
// SWAP KIOSK INTERFACE & SIMULATION
// ==========================================
function populateSwapKioskOptions() {
  const selStation = document.getElementById('kiosk-station');
  const selCustomer = document.getElementById('kiosk-customer');
  const selDepleted = document.getElementById('kiosk-depleted-pack');

  if (selStation) {
    selStation.innerHTML = state.stations.map(s =>
      `<option value="${s.id}">${s.name} (${s.zoneCode}) - Grid: $${s.gridPowerCostPerKwh}/kWh</option>`
    ).join('');
  }

  if (selCustomer) {
    const customers = state.contacts.filter(c => c.type === 'CUSTOMER');
    selCustomer.innerHTML = customers.map(c =>
      `<option value="${c.id}">${c.name}</option>`
    ).join('');
  }

  if (selDepleted) {
    selDepleted.innerHTML = state.packs.map(p =>
      `<option value="${p.id}">${p.serialNumber} - ${p.chemistry} (Current SoH: ${p.stateOfHealth.toFixed(1)}%, Status: ${p.status})</option>`
    ).join('');
  }
}

function initSwapKioskEvents() {
  const sohSlider = document.getElementById('kiosk-soh-slider');
  const sohDisplay = document.getElementById('kiosk-soh-display');
  const packSelect = document.getElementById('kiosk-depleted-pack');
  const recycleAlert = document.getElementById('kiosk-recycle-alert');
  const form = document.getElementById('swap-kiosk-form');

  if (packSelect && sohSlider) {
    packSelect.addEventListener('change', () => {
      const p = state.packs.find(x => x.id == packSelect.value);
      if (p) {
        sohSlider.value = p.stateOfHealth;
        updateSohDisplay(p.stateOfHealth);
      }
    });
  }

  if (sohSlider) {
    sohSlider.addEventListener('input', (e) => {
      updateSohDisplay(parseFloat(e.target.value));
    });
  }

  function updateSohDisplay(val) {
    if (sohDisplay) sohDisplay.textContent = `${val.toFixed(1)}%`;
    const depVisualSoH = document.getElementById('visual-depleted-soh');
    if (depVisualSoH) depVisualSoH.textContent = `${val.toFixed(1)}% SoH`;

    if (val < 70.0) {
      if (recycleAlert) recycleAlert.style.display = 'flex';
      document.getElementById('recycle-alert-text').textContent =
        `State of Health (${val.toFixed(1)}%) is below 70.0% threshold. System will autonomously flag this pack for Circular Recycling and generate a PO for EcoLithium Specialist!`;
    } else {
      if (recycleAlert) recycleAlert.style.display = 'none';
    }
  }

  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      await executeSwapSimulation();
    });
  }
}

async function executeSwapSimulation() {
  const stationId = document.getElementById('kiosk-station').value;
  const customerId = document.getElementById('kiosk-customer').value;
  const taxiPlate = document.getElementById('kiosk-plate').value || 'EV-CAB-912';
  const driverName = document.getElementById('kiosk-driver').value || 'Alex Morgan';
  const depletedPackId = document.getElementById('kiosk-depleted-pack').value;
  const customSoH = parseFloat(document.getElementById('kiosk-soh-slider').value);

  const swapBtn = document.getElementById('btn-execute-swap');
  const terminalStatus = document.getElementById('terminal-status-text');
  const arrows = document.querySelector('.swap-arrows');

  // Play animation sequence
  swapBtn.disabled = true;
  swapBtn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> Performing 3-Min Swap...`;
  terminalStatus.innerHTML = `<span style="color: var(--cyan);"><i class="fa-solid fa-robot fa-spin"></i> Robotic Arm Unlatching Depleted Pack...</span>`;

  await new Promise(r => setTimeout(r, 900));
  terminalStatus.innerHTML = `<span style="color: var(--amber);"><i class="fa-solid fa-microchip"></i> Telemetry Scan: Depleted SoH ${customSoH.toFixed(1)}%...</span>`;

  await new Promise(r => setTimeout(r, 900));
  terminalStatus.innerHTML = `<span style="color: var(--emerald);"><i class="fa-solid fa-bolt"></i> Docking Fresh Pack & Balancing Ledgers...</span>`;

  try {
    const payload = {
      stationId: parseInt(stationId),
      customerId: parseInt(customerId),
      taxiPlateNumber: taxiPlate,
      driverName: driverName,
      depletedBatteryId: parseInt(depletedPackId),
      customDepletedSoH: customSoH
    };

    const res = await fetch(`${API_BASE}/api/batteries/swaps`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (!res.ok) throw new Error('Swap failed');
    const swapEvent = await res.json();

    terminalStatus.innerHTML = `<span style="color: var(--emerald);"><i class="fa-solid fa-circle-check"></i> Swap Completed Successfully!</span>`;
    swapBtn.disabled = false;
    swapBtn.innerHTML = `<i class="fa-solid fa-bolt"></i> Execute Instant Swap`;

    // Show Digital Swap Receipt Modal
    showSwapReceiptModal(swapEvent);

    // Refresh all data
    await loadAllData();
  } catch (err) {
    console.error(err);
    terminalStatus.innerHTML = `<span style="color: var(--rose);">Swap Execution Error: ${err.message}</span>`;
    swapBtn.disabled = false;
    swapBtn.innerHTML = `<i class="fa-solid fa-bolt"></i> Execute Instant Swap`;
  }
}

function showSwapReceiptModal(swap) {
  const modal = document.getElementById('modal-swap-receipt');
  if (!modal) return;

  document.getElementById('receipt-id').textContent = swap.receiptNumber;
  document.getElementById('receipt-date').textContent = formatDate(swap.swapTimestamp);
  document.getElementById('receipt-station').textContent = `${swap.stationName} (${swap.zoneCode})`;
  document.getElementById('receipt-driver').textContent = `${swap.driverName} (${swap.taxiFleetName})`;
  document.getElementById('receipt-plate').textContent = swap.taxiPlateNumber;

  document.getElementById('receipt-depleted').textContent = `${swap.depletedBatterySerial} (${swap.depletedBatterySoH.toFixed(1)}% SoH)`;
  document.getElementById('receipt-installed').textContent = `${swap.installedBatterySerial} (${swap.installedBatterySoH ? swap.installedBatterySoH.toFixed(1) + '%' : '98.5%'} SoH)`;
  document.getElementById('receipt-energy').textContent = `${swap.energyDeliveredKwh.toFixed(2)} kWh`;
  document.getElementById('receipt-grid-cost').textContent = `$${(swap.gridElectricityCost || 0).toFixed(2)}`;
  document.getElementById('receipt-total-fee').textContent = `$${(swap.serviceFee || 38.50).toFixed(2)}`;

  const recycleStatusEl = document.getElementById('receipt-recycling-status');
  if (swap.autoRoutedToRecycling) {
    recycleStatusEl.innerHTML = `
      <div style="color: var(--rose); font-weight: 700; margin-top: 8px;">
        <i class="fa-solid fa-recycle"></i> CIRCULAR RECYCLING AUTO-ROUTED
      </div>
      <div style="font-size: 0.76rem; color: #fca5a5;">
        ${swap.recyclingReason}
      </div>
      <div style="font-size: 0.74rem; color: var(--text-dim); margin-top: 4px;">
        Auto-issued Purchase Order to EcoLithium Recycling Specialist.
      </div>
    `;
  } else {
    recycleStatusEl.innerHTML = `
      <div style="color: var(--emerald); font-weight: 600; margin-top: 6px;">
        <i class="fa-solid fa-circle-check"></i> Pack Health Nominal (${swap.depletedBatterySoH.toFixed(1)}%). Recharging in bay.
      </div>
    `;
  }

  modal.classList.add('active');
}

// ==========================================
// ACCOUNTING & TRANSACTIONS
// ==========================================
function loadAccountingView() {
  renderContactsTable();
  renderProductsTable();
  renderChartOfAccounts();
  renderJournalEntriesTable();
  renderPurchaseOrdersTable();
  renderVendorBillsTable();
  renderSalesOrdersTable();
  renderCustomerInvoicesTable();
  renderPaymentsTable();
}

function renderContactsTable() {
  const tbody = document.getElementById('contacts-table-body');
  if (!tbody) return;

  tbody.innerHTML = '';
  state.contacts.forEach(c => {
    const tr = document.createElement('tr');
    let typeBadge = '';
    if (c.type === 'CUSTOMER') typeBadge = `<span class="badge badge-cyan">Electric Taxi Fleet (Customer)</span>`;
    else if (c.type === 'VENDOR_MANUFACTURER') typeBadge = `<span class="badge badge-emerald">Cell Manufacturer (Vendor)</span>`;
    else if (c.type === 'VENDOR_RECYCLER') typeBadge = `<span class="badge badge-rose">Recycling Specialist (Vendor)</span>`;

    tr.innerHTML = `
      <td><strong>${c.name}</strong></td>
      <td>${typeBadge}</td>
      <td>${c.email || 'N/A'}</td>
      <td>${c.phone || 'N/A'}</td>
      <td>${c.taxNumber || 'N/A'}</td>
      <td>${c.address || 'Metropolis EV Hub'}</td>
    `;
    tbody.appendChild(tr);
  });
}

function renderProductsTable() {
  const tbody = document.getElementById('products-table-body');
  if (!tbody) return;

  tbody.innerHTML = '';
  state.products.forEach(p => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><code>${p.code}</code></td>
      <td><strong>${p.name}</strong></td>
      <td><span class="badge badge-cyan">${p.type}</span></td>
      <td><strong>$${(p.standardPrice || 0).toFixed(2)}</strong> / ${p.unitOfMeasure}</td>
      <td>Income: <code>${p.incomeAccountCode || 'None'}</code> | Expense: <code>${p.expenseAccountCode || 'None'}</code></td>
      <td>${p.description || ''}</td>
    `;
    tbody.appendChild(tr);
  });
}

function renderChartOfAccounts() {
  const tbody = document.getElementById('coa-table-body');
  if (!tbody) return;

  tbody.innerHTML = '';
  state.coa.forEach(a => {
    const tr = document.createElement('tr');
    let typeBadge = '';
    if (a.type === 'ASSET') typeBadge = `<span class="badge badge-emerald">Asset</span>`;
    else if (a.type === 'LIABILITY') typeBadge = `<span class="badge badge-rose">Liability</span>`;
    else if (a.type === 'EQUITY') typeBadge = `<span class="badge badge-indigo">Equity</span>`;
    else if (a.type === 'INCOME') typeBadge = `<span class="badge badge-cyan">Income</span>`;
    else if (a.type === 'EXPENSE') typeBadge = `<span class="badge badge-amber">Expense</span>`;

    tr.innerHTML = `
      <td><code>${a.code}</code></td>
      <td><strong>${a.name}</strong></td>
      <td>${typeBadge}</td>
      <td>${a.subCategory || ''}</td>
      <td style="font-family: var(--font-mono); font-weight: 700; color: #fff;">
        $${(a.balance || 0).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function renderJournalEntriesTable() {
  const tbody = document.getElementById('journal-entries-table-body');
  if (!tbody) return;

  tbody.innerHTML = '';
  state.journalEntries.forEach(je => {
    const tr = document.createElement('tr');

    let linesSummary = (je.lines || []).map(l =>
      `<div><code>${l.accountCode}</code> ${l.accountName}: Dr $${(l.debitAmount||0).toFixed(2)} | Cr $${(l.creditAmount||0).toFixed(2)}</div>`
    ).join('');

    tr.innerHTML = `
      <td><code>${je.entryNumber}</code></td>
      <td>${formatDate(je.entryDate)}</td>
      <td><span class="badge badge-emerald">${je.journalCode}</span></td>
      <td><strong>${je.description}</strong><br><small style="color: var(--text-dim);">${je.reference || ''}</small></td>
      <td style="font-size: 0.78rem;">${linesSummary}</td>
      <td style="font-family: var(--font-mono); font-weight: 700;">$${(je.totalDebit || 0).toFixed(2)}</td>
      <td><span class="badge ${je.isBalanced ? 'badge-emerald' : 'badge-rose'}">${je.isBalanced ? 'Balanced' : 'Unbalanced'}</span></td>
    `;
    tbody.appendChild(tr);
  });
}

function renderPurchaseOrdersTable() {
  const tbody = document.getElementById('po-table-body');
  if (!tbody) return;

  tbody.innerHTML = '';
  state.purchaseOrders.forEach(po => {
    const tr = document.createElement('tr');

    let actionBtn = '';
    if (po.status === 'CONFIRMED' || po.status === 'DRAFT') {
      actionBtn = `<button class="btn btn-sm btn-cyan" onclick="convertPoToBill(${po.id})"><i class="fa-solid fa-file-invoice"></i> Convert to Bill</button>`;
    } else {
      actionBtn = `<span class="badge badge-emerald"><i class="fa-solid fa-check"></i> Billed</span>`;
    }

    tr.innerHTML = `
      <td><code>${po.poNumber}</code></td>
      <td>${formatDate(po.orderDate)}</td>
      <td><strong>${po.vendorName}</strong></td>
      <td>${po.serviceType || 'Recycling Service'} (${po.moduleCount} modules)</td>
      <td style="font-family: var(--font-mono); font-weight: 700;">$${(po.totalAmount || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
      <td><span class="badge ${po.status === 'BILLED' ? 'badge-emerald' : 'badge-amber'}">${po.status}</span></td>
      <td>${actionBtn}</td>
    `;
    tbody.appendChild(tr);
  });
}

async function convertPoToBill(poId) {
  try {
    const res = await fetch(`${API_BASE}/api/transactions/purchase-orders/${poId}/convert-to-bill`, {
      method: 'POST'
    });
    if (!res.ok) throw new Error('Failed to convert PO');
    const bill = await res.json();
    alert(`Vendor Bill ${bill.billNumber} created! Double-entry ledger posted to Purchase Journal.`);
    await loadAllData();
  } catch (err) {
    alert(err.message);
  }
}

function renderVendorBillsTable() {
  const tbody = document.getElementById('bills-table-body');
  if (!tbody) return;

  tbody.innerHTML = '';
  state.vendorBills.forEach(b => {
    const tr = document.createElement('tr');

    let payAction = '';
    if (b.status === 'PENDING') {
      payAction = `<button class="btn btn-sm btn-primary" onclick="openPaymentModal('BILL', ${b.id}, '${b.billNumber}', ${b.amount}, '${b.vendorName}')"><i class="fa-solid fa-money-bill-transfer"></i> Pay via Bank</button>`;
    } else {
      payAction = `<span class="badge badge-emerald"><i class="fa-solid fa-check-double"></i> Paid (${b.paymentReference || ''})</span>`;
    }

    tr.innerHTML = `
      <td><code>${b.billNumber}</code></td>
      <td>${formatDate(b.billDate)}</td>
      <td><strong>${b.vendorName}</strong></td>
      <td>PO: <code>${b.poNumber}</code></td>
      <td style="font-family: var(--font-mono); font-weight: 700;">$${(b.amount || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
      <td><span class="badge ${b.status === 'PAID' ? 'badge-emerald' : 'badge-rose'}">${b.status}</span></td>
      <td>${payAction}</td>
    `;
    tbody.appendChild(tr);
  });
}

function renderSalesOrdersTable() {
  const tbody = document.getElementById('so-table-body');
  if (!tbody) return;

  tbody.innerHTML = '';
  state.salesOrders.forEach(so => {
    const tr = document.createElement('tr');

    let actionBtn = '';
    if (so.status === 'CONFIRMED' || so.status === 'DRAFT') {
      actionBtn = `<button class="btn btn-sm btn-cyan" onclick="convertSoToInvoice(${so.id})"><i class="fa-solid fa-file-invoice-dollar"></i> Convert to Invoice</button>`;
    } else {
      actionBtn = `<span class="badge badge-emerald"><i class="fa-solid fa-check"></i> Invoiced</span>`;
    }

    tr.innerHTML = `
      <td><code>${so.soNumber}</code></td>
      <td>${formatDate(so.orderDate)}</td>
      <td><strong>${so.customerName}</strong></td>
      <td>${so.planName} (${so.fleetVehicleCount} vehicles)</td>
      <td style="font-family: var(--font-mono); font-weight: 700;">$${(so.totalAmount || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
      <td><span class="badge ${so.status === 'INVOICED' ? 'badge-emerald' : 'badge-cyan'}">${so.status}</span></td>
      <td>${actionBtn}</td>
    `;
    tbody.appendChild(tr);
  });
}

async function convertSoToInvoice(soId) {
  try {
    const res = await fetch(`${API_BASE}/api/transactions/sales-orders/${soId}/convert-to-invoice`, {
      method: 'POST'
    });
    if (!res.ok) throw new Error('Failed to convert SO');
    const inv = await res.json();
    alert(`Customer Invoice ${inv.invoiceNumber} generated! Revenue recorded.`);
    await loadAllData();
  } catch (err) {
    alert(err.message);
  }
}

function renderCustomerInvoicesTable() {
  const tbody = document.getElementById('invoices-table-body');
  if (!tbody) return;

  tbody.innerHTML = '';
  state.customerInvoices.forEach(inv => {
    const tr = document.createElement('tr');

    let payAction = '';
    if (inv.status === 'PENDING') {
      payAction = `<button class="btn btn-sm btn-primary" onclick="openPaymentModal('INVOICE', ${inv.id}, '${inv.invoiceNumber}', ${inv.amount}, '${inv.customerName}')"><i class="fa-solid fa-hand-holding-dollar"></i> Collect Bank Payment</button>`;
    } else {
      payAction = `<span class="badge badge-emerald"><i class="fa-solid fa-check-double"></i> Settled (${inv.paymentReference || ''})</span>`;
    }

    tr.innerHTML = `
      <td><code>${inv.invoiceNumber}</code></td>
      <td>${formatDate(inv.invoiceDate)}</td>
      <td><strong>${inv.customerName}</strong></td>
      <td>${inv.description || (inv.swapReceiptNumber ? 'Swap ' + inv.swapReceiptNumber : 'Subscription')}</td>
      <td style="font-family: var(--font-mono); font-weight: 700;">$${(inv.amount || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
      <td><span class="badge ${inv.status === 'PAID' ? 'badge-emerald' : 'badge-amber'}">${inv.status}</span></td>
      <td>${payAction}</td>
    `;
    tbody.appendChild(tr);
  });
}

function renderPaymentsTable() {
  const tbody = document.getElementById('payments-table-body');
  if (!tbody) return;

  tbody.innerHTML = '';
  state.payments.forEach(p => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><code>${p.paymentNumber}</code></td>
      <td>${formatDate(p.paymentDate)}</td>
      <td><span class="badge ${p.type === 'CUSTOMER_RECEIPT' ? 'badge-emerald' : 'badge-rose'}">${p.type}</span></td>
      <td><strong>${p.partnerName}</strong></td>
      <td>Doc: <code>${p.referenceDocNumber || p.referenceId}</code></td>
      <td style="font-family: var(--font-mono); font-weight: 700;">$${(p.amount || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
      <td>${p.paymentMethod || 'Bank Transfer'} (Acc <code>${p.bankAccountCode || '1020'}</code>)</td>
    `;
    tbody.appendChild(tr);
  });
}

// Payment Modal
function openPaymentModal(refType, refId, docNum, amount, partnerName) {
  const modal = document.getElementById('modal-payment');
  if (!modal) return;

  document.getElementById('pay-ref-type').value = refType;
  document.getElementById('pay-ref-id').value = refId;
  document.getElementById('pay-doc-num').value = docNum;
  document.getElementById('pay-partner-name').value = partnerName;
  document.getElementById('pay-amount').value = amount;
  document.getElementById('pay-modal-title').textContent =
    refType === 'INVOICE' ? `Collect Payment for Invoice ${docNum}` : `Disburse Payment for Bill ${docNum}`;

  modal.classList.add('active');
}

// ==========================================
// CIRCULAR RECYCLING & ZONE BUDGET VIEW
// ==========================================
async function loadCircularAndBudgetView() {
  try {
    const res = await fetch(`${API_BASE}/api/budgets/performance`);
    state.budgetPerformance = await res.json();
    renderCircularRecyclingView();
  } catch (err) {
    console.error(err);
  }
}

function renderCircularRecyclingView() {
  // 1. Degraded Packs Table
  const tbody = document.getElementById('degraded-packs-table-body');
  if (tbody) {
    tbody.innerHTML = '';
    const degraded = state.packs.filter(p => p.stateOfHealth < 70.0 || p.status === 'RETIRED_FOR_RECYCLING');

    document.getElementById('circ-recycled-count').textContent = `${degraded.length} Modules`;

    // Estimated reclaimed metals (approx 75kWh pack has ~8kg Li, ~14kg Co, ~30kg Ni)
    const totalLi = (degraded.length * 8.2).toFixed(1);
    const totalCo = (degraded.length * 13.5).toFixed(1);
    const totalNi = (degraded.length * 28.6).toFixed(1);

    document.getElementById('metal-li').textContent = `${totalLi} kg`;
    document.getElementById('metal-co').textContent = `${totalCo} kg`;
    document.getElementById('metal-ni').textContent = `${totalNi} kg`;

    degraded.forEach(p => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><strong>${p.serialNumber}</strong></td>
        <td>${p.chemistry}</td>
        <td>
          <span style="color: var(--rose); font-weight: 700;">${p.stateOfHealth.toFixed(1)}% SoH</span>
          <div class="soh-bar-bg">
            <div class="soh-bar-fill soh-degraded" style="width: ${p.stateOfHealth}%;"></div>
          </div>
        </td>
        <td>${p.cycleCount} cycles</td>
        <td><span class="badge badge-rose"><i class="fa-solid fa-recycle"></i> Retired for Recycling</span></td>
        <td>EcoLithium Circular Specialist Ltd</td>
        <td>
          <button class="btn btn-sm btn-cyan" onclick="openCreatePoForRecycle('${p.serialNumber}')">
            <i class="fa-solid fa-file-contract"></i> Dispatch PO
          </button>
        </td>
      `;
      tbody.appendChild(tr);
    });
  }

  // 2. Budget Performance Table
  const budgetTbody = document.getElementById('budget-perf-table-body');
  if (budgetTbody && state.budgetPerformance) {
    budgetTbody.innerHTML = '';
    state.budgetPerformance.forEach(b => {
      const tr = document.createElement('tr');

      const gridBadge = b.gridBudgetUtilizationPct > 90 ? 'badge-rose' : (b.gridBudgetUtilizationPct > 70 ? 'badge-amber' : 'badge-emerald');
      const recycBadge = b.recyclingBudgetUtilizationPct > 90 ? 'badge-rose' : (b.recyclingBudgetUtilizationPct > 70 ? 'badge-amber' : 'badge-emerald');

      tr.innerHTML = `
        <td><strong>${b.zoneName}</strong> (<code>${b.zoneCode}</code>)</td>
        <td>${b.totalSwaps} Swaps</td>
        <td>
          Planned: $${b.plannedRevenue.toLocaleString()}<br>
          Actual: <strong>$${b.actualRevenue.toLocaleString()}</strong><br>
          <small style="color: ${b.revenueVariance >= 0 ? 'var(--emerald)' : 'var(--rose)'}">
            ${b.revenueVariance >= 0 ? '+' : ''}$${b.revenueVariance.toLocaleString()}
          </small>
        </td>
        <td>
          Planned: $${b.plannedGridExpense.toLocaleString()}<br>
          Actual: <strong>$${b.actualGridExpense.toLocaleString()}</strong><br>
          <span class="badge ${gridBadge}">${b.gridBudgetUtilizationPct}% Utilized</span>
        </td>
        <td>
          Planned: $${b.plannedRecyclingExpense.toLocaleString()}<br>
          Actual: <strong>$${b.actualRecyclingExpense.toLocaleString()}</strong><br>
          <span class="badge ${recycBadge}">${b.recyclingBudgetUtilizationPct}% Utilized</span>
        </td>
        <td style="font-family: var(--font-mono); font-weight: 700; color: ${b.netOperatingActual >= 0 ? 'var(--emerald)' : 'var(--rose)'}">
          ${b.netOperatingActual >= 0 ? '+' : ''}$${b.netOperatingActual.toLocaleString()}
        </td>
      `;
      budgetTbody.appendChild(tr);
    });
  }
}

function openCreatePoForRecycle(serial) {
  const modal = document.getElementById('modal-new-po');
  if (!modal) return;
  document.getElementById('po-notes').value = `Circular batch recycling for degraded battery pack ${serial}`;
  modal.classList.add('active');
}

// ==========================================
// FINANCIAL REPORTS AUDITOR
// ==========================================
async function loadFinancialReports() {
  try {
    const [bsRes, pnlRes, budRes] = await Promise.all([
      fetch(`${API_BASE}/api/reports/balance-sheet`),
      fetch(`${API_BASE}/api/reports/profit-and-loss`),
      fetch(`${API_BASE}/api/reports/budget-report`)
    ]);

    state.balanceSheet = await bsRes.json();
    state.pnl = await pnlRes.json();
    state.budgetPerformance = await budRes.json();

    renderBalanceSheet();
    renderProfitAndLoss();
    renderBudgetReportInReportsView();
  } catch (err) {
    console.error('Error loading reports:', err);
  }
}

function renderBalanceSheet() {
  const bs = state.balanceSheet;
  if (!bs) return;

  document.getElementById('bs-gen-date').textContent = formatDate(bs.generatedAt);
  document.getElementById('bs-total-assets').textContent = `$${(bs.totalAssets || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}`;
  document.getElementById('bs-total-liabilities').textContent = `$${(bs.totalLiabilities || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}`;
  document.getElementById('bs-retained-surplus').textContent = `$${(bs.retainedSurplus || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}`;
  document.getElementById('bs-total-liab-equity').textContent = `$${(bs.totalLiabilitiesAndEquity || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}`;

  const balanceStatusBadge = document.getElementById('bs-balance-status');
  if (bs.isBalanced) {
    balanceStatusBadge.innerHTML = `<span class="badge badge-emerald"><i class="fa-solid fa-scale-balanced"></i> Balanced (Assets = Liabilities + Equity)</span>`;
  } else {
    balanceStatusBadge.innerHTML = `<span class="badge badge-rose"><i class="fa-solid fa-triangle-exclamation"></i> Out of Balance</span>`;
  }

  // Render assets table
  const assetTbody = document.getElementById('bs-assets-tbody');
  if (assetTbody) {
    assetTbody.innerHTML = (bs.assets || []).map(a => `
      <tr>
        <td><code>${a.code}</code></td>
        <td><strong>${a.name}</strong> (${a.subCategory})</td>
        <td style="text-align: right; font-family: var(--font-mono); font-weight: 600;">$${(a.balance || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
      </tr>
    `).join('');
  }

  // Render liabilities table
  const liabTbody = document.getElementById('bs-liabilities-tbody');
  if (liabTbody) {
    liabTbody.innerHTML = (bs.liabilities || []).map(l => `
      <tr>
        <td><code>${l.code}</code></td>
        <td><strong>${l.name}</strong> (${l.subCategory})</td>
        <td style="text-align: right; font-family: var(--font-mono); font-weight: 600;">$${(l.balance || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
      </tr>
    `).join('');
  }
}

function renderProfitAndLoss() {
  const pnl = state.pnl;
  if (!pnl) return;

  document.getElementById('pnl-gen-date').textContent = formatDate(pnl.generatedAt);
  document.getElementById('pnl-total-income').textContent = `$${(pnl.totalIncome || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}`;
  document.getElementById('pnl-total-expenses').textContent = `$${(pnl.totalExpenses || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}`;
  
  const netEl = document.getElementById('pnl-net-income');
  netEl.textContent = `$${(pnl.netOperatingIncome || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}`;
  netEl.style.color = pnl.netOperatingIncome >= 0 ? 'var(--emerald)' : 'var(--rose)';

  document.getElementById('pnl-margin').textContent = `${(pnl.operatingMarginPct || 0).toFixed(1)}% Operating Margin`;

  const incTbody = document.getElementById('pnl-income-tbody');
  if (incTbody) {
    incTbody.innerHTML = (pnl.incomeAccounts || []).map(i => `
      <tr>
        <td><code>${i.code}</code></td>
        <td><strong>${i.name}</strong></td>
        <td style="text-align: right; font-family: var(--font-mono); font-weight: 600;">$${(i.balance || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
      </tr>
    `).join('');
  }

  const expTbody = document.getElementById('pnl-expense-tbody');
  if (expTbody) {
    expTbody.innerHTML = (pnl.expenseAccounts || []).map(e => `
      <tr>
        <td><code>${e.code}</code></td>
        <td><strong>${e.name}</strong></td>
        <td style="text-align: right; font-family: var(--font-mono); font-weight: 600;">$${(e.balance || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
      </tr>
    `).join('');
  }
}

function renderBudgetReportInReportsView() {
  const tbody = document.getElementById('rep-budget-table-body');
  if (!tbody || !state.budgetPerformance) return;

  tbody.innerHTML = '';
  state.budgetPerformance.forEach(b => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>${b.zoneName}</strong></td>
      <td>${b.totalSwaps}</td>
      <td>$${b.actualRevenue.toLocaleString()} <small>($${b.plannedRevenue.toLocaleString()} plan)</small></td>
      <td>$${b.actualGridExpense.toLocaleString()} <small>(${b.gridBudgetUtilizationPct}%)</small></td>
      <td>$${b.actualRecyclingExpense.toLocaleString()} <small>(${b.recyclingBudgetUtilizationPct}%)</small></td>
      <td style="font-family: var(--font-mono); font-weight: 700; color: ${b.netOperatingActual >= 0 ? 'var(--emerald)' : 'var(--rose)'}">
        $${b.netOperatingActual.toLocaleString()}
      </td>
    `;
    tbody.appendChild(tr);
  });
}

// ==========================================
// MODALS & FORMS
// ==========================================
function initModals() {
  // Close buttons
  document.querySelectorAll('.modal-close, .modal-cancel').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.modal-backdrop').forEach(m => m.classList.remove('active'));
    });
  });

  // Modal Triggers
  const btnNewPack = document.getElementById('btn-open-new-pack-modal');
  if (btnNewPack) {
    btnNewPack.addEventListener('click', () => {
      document.getElementById('modal-new-pack').classList.add('active');
    });
  }

  const btnNewContact = document.getElementById('btn-open-new-contact-modal');
  if (btnNewContact) {
    btnNewContact.addEventListener('click', () => {
      document.getElementById('modal-new-contact').classList.add('active');
    });
  }

  const btnNewPo = document.getElementById('btn-open-new-po-modal');
  if (btnNewPo) {
    btnNewPo.addEventListener('click', () => {
      document.getElementById('modal-new-po').classList.add('active');
    });
  }

  const btnNewSo = document.getElementById('btn-open-new-so-modal');
  if (btnNewSo) {
    btnNewSo.addEventListener('click', () => {
      document.getElementById('modal-new-so').classList.add('active');
    });
  }

  // Form Submissions
  // 1. New Battery Pack Asset (POST /api/batteries/packs)
  const formNewPack = document.getElementById('form-new-pack');
  if (formNewPack) {
    formNewPack.addEventListener('submit', async (e) => {
      e.preventDefault();
      const serial = document.getElementById('pack-serial').value;
      const chemistry = document.getElementById('pack-chemistry').value;
      const cap = parseFloat(document.getElementById('pack-cap').value);
      const soh = parseFloat(document.getElementById('pack-soh').value);
      const zone = document.getElementById('pack-zone').value;
      const valuation = parseFloat(document.getElementById('pack-val').value);

      try {
        const res = await fetch(`${API_BASE}/api/batteries/packs`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            serialNumber: serial,
            chemistry: chemistry,
            nominalCapacityKwh: cap,
            stateOfHealth: soh,
            stationZone: zone,
            assetValuation: valuation,
            status: soh < 70 ? 'RETIRED_FOR_RECYCLING' : 'CHARGING_AT_BAY'
          })
        });

        if (!res.ok) throw new Error('Failed to register pack');
        alert(`Battery Pack ${serial} registered and logged in Balance Sheet assets!`);
        document.getElementById('modal-new-pack').classList.remove('active');
        formNewPack.reset();
        await loadAllData();
      } catch (err) {
        alert(err.message);
      }
    });
  }

  // 2. New Contact Form
  const formContact = document.getElementById('form-new-contact');
  if (formContact) {
    formContact.addEventListener('submit', async (e) => {
      e.preventDefault();
      const name = document.getElementById('contact-name').value;
      const type = document.getElementById('contact-type').value;
      const email = document.getElementById('contact-email').value;
      const phone = document.getElementById('contact-phone').value;
      const address = document.getElementById('contact-address').value;

      try {
        const res = await fetch(`${API_BASE}/api/contacts`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name, type, email, phone, address, outstandingBalance: 0.0 })
        });
        if (!res.ok) throw new Error('Failed to save contact');
        document.getElementById('modal-new-contact').classList.remove('active');
        formContact.reset();
        await loadAllData();
      } catch (err) {
        alert(err.message);
      }
    });
  }

  // 3. New PO Form
  const formPo = document.getElementById('form-new-po');
  if (formPo) {
    formPo.addEventListener('submit', async (e) => {
      e.preventDefault();
      const vendorName = document.getElementById('po-vendor-name').value;
      const serviceType = document.getElementById('po-service-type').value;
      const moduleCount = parseInt(document.getElementById('po-modules').value);
      const unitPrice = parseFloat(document.getElementById('po-unit-price').value);
      const notes = document.getElementById('po-notes').value;

      try {
        const res = await fetch(`${API_BASE}/api/transactions/purchase-orders`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            vendorName,
            serviceType,
            moduleCount,
            unitPrice,
            totalAmount: moduleCount * unitPrice,
            notes
          })
        });
        if (!res.ok) throw new Error('Failed to create PO');
        document.getElementById('modal-new-po').classList.remove('active');
        formPo.reset();
        await loadAllData();
      } catch (err) {
        alert(err.message);
      }
    });
  }

  // 4. New SO Form
  const formSo = document.getElementById('form-new-so');
  if (formSo) {
    formSo.addEventListener('submit', async (e) => {
      e.preventDefault();
      const customerName = document.getElementById('so-customer-name').value;
      const planName = document.getElementById('so-plan-name').value;
      const fleetCount = parseInt(document.getElementById('so-fleet-count').value);
      const monthlyRate = parseFloat(document.getElementById('so-monthly-rate').value);

      try {
        const res = await fetch(`${API_BASE}/api/transactions/sales-orders`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            customerName,
            planName,
            fleetVehicleCount: fleetCount,
            monthlyRatePerVehicle: monthlyRate,
            totalAmount: fleetCount * monthlyRate,
            status: 'CONFIRMED'
          })
        });
        if (!res.ok) throw new Error('Failed to create SO');
        document.getElementById('modal-new-so').classList.remove('active');
        formSo.reset();
        await loadAllData();
      } catch (err) {
        alert(err.message);
      }
    });
  }

  // 5. Payment Settlement Form
  const formPayment = document.getElementById('form-payment');
  if (formPayment) {
    formPayment.addEventListener('submit', async (e) => {
      e.preventDefault();
      const refType = document.getElementById('pay-ref-type').value;
      const refId = parseInt(document.getElementById('pay-ref-id').value);
      const docNum = document.getElementById('pay-doc-num').value;
      const partnerName = document.getElementById('pay-partner-name').value;
      const amount = parseFloat(document.getElementById('pay-amount').value);
      const method = document.getElementById('pay-method').value;

      try {
        const res = await fetch(`${API_BASE}/api/transactions/payments`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            type: refType === 'INVOICE' ? 'CUSTOMER_RECEIPT' : 'VENDOR_PAYMENT',
            referenceType: refType,
            referenceId: refId,
            referenceDocNumber: docNum,
            partnerName: partnerName,
            amount: amount,
            paymentMethod: method,
            bankAccountCode: '1020'
          })
        });
        if (!res.ok) throw new Error('Failed to process payment');
        alert(`Payment of $${amount.toFixed(2)} settled via Bank! Balanced journal entry posted.`);
        document.getElementById('modal-payment').classList.remove('active');
        await loadAllData();
      } catch (err) {
        alert(err.message);
      }
    });
  }
}

// Utility formatting
function formatDate(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}
