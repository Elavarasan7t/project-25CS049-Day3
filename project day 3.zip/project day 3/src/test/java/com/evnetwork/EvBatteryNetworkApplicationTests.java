package com.evnetwork;

import com.evnetwork.controller.BatteryController;
import com.evnetwork.entity.BatteryPack;
import com.evnetwork.entity.BatterySwapEvent;
import com.evnetwork.service.BatteryService;
import com.evnetwork.service.ReportService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class EvBatteryNetworkApplicationTests {

    @Autowired
    private BatteryService batteryService;

    @Autowired
    private ReportService reportService;

    @Autowired
    private BatteryController batteryController;

    @Test
    void contextLoads() {
        assertNotNull(batteryService);
        assertNotNull(reportService);
    }

    @Test
    void testStep1CreateMasterData() {
        BatteryPack pack = new BatteryPack();
        pack.setSerialNumber("TEST-BP-9999");
        pack.setChemistry("LFP");
        pack.setNominalCapacityKwh(75.0);
        pack.setStateOfHealth(99.0);
        pack.setStationZone("ZONE-A");
        pack.setAssetValuation(8500.0);

        BatteryPack registered = batteryService.registerBatteryPack(pack);
        assertNotNull(registered.getId());
        assertEquals("TEST-BP-9999", registered.getSerialNumber());
        assertEquals(BatteryPack.BatteryStatus.CHARGING_AT_BAY, registered.getStatus());
    }

    @Test
    void testStep2ProcessSwapWithAutoRecyclingWhenSohBelow70() {
        // Find or create degraded pack
        BatteryPack degradedPack = new BatteryPack();
        degradedPack.setSerialNumber("TEST-DEGRADED-" + System.currentTimeMillis());
        degradedPack.setChemistry("NMC");
        degradedPack.setNominalCapacityKwh(82.0);
        degradedPack.setStateOfHealth(65.0); // Below 70% threshold
        degradedPack.setStationZone("ZONE-A");
        degradedPack = batteryService.registerBatteryPack(degradedPack);

        BatterySwapEvent swap = batteryService.processBatterySwap(
                1L,
                1L,
                "TEST-CAB-123",
                "Test Driver",
                degradedPack.getId(),
                null,
                65.0
        );

        assertNotNull(swap);
        assertTrue(swap.getAutoRoutedToRecycling(), "Pack with SoH < 70% must be auto-routed to recycling");
        assertEquals(BatteryPack.BatteryStatus.RETIRED_FOR_RECYCLING,
                batteryService.getPackById(degradedPack.getId()).get().getStatus());
    }

    @Test
    void testStep4FinancialReports() {
        Map<String, Object> bs = reportService.getBalanceSheet();
        assertNotNull(bs);
        assertTrue((Double) bs.get("totalAssets") > 0);
        assertTrue((Boolean) bs.get("isBalanced"), "Balance sheet must be balanced");

        Map<String, Object> pnl = reportService.getProfitAndLoss();
        assertNotNull(pnl);
        assertTrue((Double) pnl.get("totalIncome") > 0);
    }
}
